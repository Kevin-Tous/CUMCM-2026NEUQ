# Person A reproducible result summary

- Independent cells: 421
- Independent cycle records: 313461
- XJTU raw cells with protocol labels: 55
- Median phase transitions: 0.188 and 0.779 of observed life
- XJTU held-out-cell R2 / MAE: 0.941 / 0.0088
- TJU held-out-cell R2 / MAE: 0.907 / 0.0127
- Resistance output is a semi-empirical simulation proxy, not an experimental measurement.