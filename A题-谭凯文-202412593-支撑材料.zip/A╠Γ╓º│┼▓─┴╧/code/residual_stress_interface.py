"""Build a residual-expanded RUL stress-test interface without overwriting baseline."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    root = Path(__file__).resolve().parents[1]
    p.add_argument("--input", type=Path, default=root / "results/prediction/tables/battery_prediction_interface.csv")
    p.add_argument("--backtest", type=Path, default=root / "results/validation/rul_forward_backtest_detail.csv")
    p.add_argument("--output", type=Path, default=root / "results/prediction/tables/battery_prediction_interface_residual_stress.csv")
    p.add_argument("--summary", type=Path, default=root / "results/prediction/tables/residual_stress_calibration_summary.json")
    p.add_argument("--coverage", type=float, default=0.90)
    return p.parse_args()


def main() -> None:
    args = parse_args()
    cells = pd.read_csv(args.input)
    bt = pd.read_csv(args.backtest)
    valid_bt = bt[bt["rul_valid"].astype(str).str.lower().isin({"true", "1"})].copy()
    residuals = (valid_bt["rul_median"] - valid_bt["true_rul"]).abs().dropna().to_numpy()
    if len(residuals) < 10:
        raise ValueError("Too few valid forward RUL backtests for the residual stress diagnostic.")
    rank = min(len(residuals), int(np.ceil((len(residuals) + 1) * args.coverage))) - 1
    q = float(np.sort(residuals)[rank])

    out = cells.copy()
    active = out["prediction_valid"].astype(str).str.lower().isin({"true", "1"})
    out["RUL_lower_empirical"] = out["RUL_lower"]
    out["RUL_upper_empirical"] = out["RUL_upper"]
    out["RUL_lower_calibrated"] = np.nan
    out["RUL_upper_calibrated"] = np.nan
    out.loc[active, "RUL_lower_calibrated"] = np.maximum(0.0, out.loc[active, "RUL_pred"] - q)
    out.loc[active, "RUL_upper_calibrated"] = out.loc[active, "RUL_pred"] + q
    out.loc[active, "RUL_lower"] = out.loc[active, "RUL_lower_calibrated"]
    out.loc[active, "RUL_upper"] = out.loc[active, "RUL_upper_calibrated"]
    out.loc[active, "uncertainty_width"] = out.loc[active, "RUL_upper"] - out.loc[active, "RUL_lower"]
    out["rul_bound_type"] = "residual_stress_LOOCV_absolute_residual"
    out["calibration_sample_size"] = int(len(residuals))
    out["calibration_half_width_cycles"] = q
    args.output.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(args.output, index=False, encoding="utf-8-sig")

    summary = {
        "method": "finite-sample 90% absolute-residual expansion from leave-one-cell-out 85%-EOL backtest",
        "coverage_target": args.coverage,
        "calibration_sample_size": int(len(residuals)),
        "half_width_cycles": q,
        "scope": "residual-expanded stress test only; not a confidence guarantee across observation stages or external batches",
        "valid_cells": int(active.sum()),
        "calibrated_lower_ge_8": int((out.loc[active, "RUL_lower"] >= 8).sum()),
        "calibrated_lower_ge_15": int((out.loc[active, "RUL_lower"] >= 15).sum()),
        "calibrated_lower_ge_40": int((out.loc[active, "RUL_lower"] >= 40).sum()),
    }
    args.summary.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
