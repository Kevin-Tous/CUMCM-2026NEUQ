"""SOH trajectory post-processing and threshold RUL with intervals."""
from __future__ import annotations
import numpy as np


def enforce_nonincreasing(values, regen_tolerance=0.002):
    out = np.asarray(values, float).copy()
    for i in range(1, len(out)):
        out[i] = min(out[i], out[i - 1] + regen_tolerance)
    return out


def threshold_crossing(cycle, soh, threshold=0.8):
    cycle, soh = np.asarray(cycle, float), np.asarray(soh, float)
    hit = np.flatnonzero(soh <= threshold)
    if len(hit):
        j = int(hit[0])
        if j == 0: return float(cycle[0])
        frac = (soh[j - 1] - threshold) / max(soh[j - 1] - soh[j], 1e-9)
        return float(cycle[j - 1] + frac * (cycle[j] - cycle[j - 1]))
    tail = min(20, len(cycle))
    slope = np.polyfit(cycle[-tail:], soh[-tail:], 1)[0] if tail >= 2 else 0.0
    return float(cycle[-1] + (threshold - soh[-1]) / slope) if slope < -1e-8 else np.nan


def _empty(status, current_soh, horizon_limit, valid_fraction=0.0):
    return {"rul_median": np.nan, "rul_lower": np.nan, "rul_upper": np.nan,
            "eol_cycle_median": np.nan, "rul_interval_width": np.nan,
            "rul_status": status, "rul_valid": False,
            "current_soh_pred": float(current_soh),
            "valid_sample_fraction": float(valid_fraction),
            "rul_horizon_limit": float(horizon_limit)}


def rul_from_samples(cycle, samples, current_cycle=None, threshold=0.8,
                     max_extrapolation_cycles=2000,
                     max_extrapolation_factor=2.0,
                     max_interval_width_cycles=1000,
                     min_valid_sample_fraction=0.5):
    cycle = np.asarray(cycle, float)
    samples = np.asarray(samples, float)
    current_cycle = float(cycle[-1] if current_cycle is None else current_cycle)
    current_soh = float(np.nanmedian(samples[:, -1]))
    observed_span = max(current_cycle - float(cycle[0]) + 1.0, 1.0)
    horizon_limit = min(float(max_extrapolation_cycles),
                        float(max_extrapolation_factor) * observed_span)
    crossings = np.array([threshold_crossing(cycle, enforce_nonincreasing(s), threshold) for s in samples])
    ruls = crossings - current_cycle
    finite = np.isfinite(ruls)
    # Never expose negative RUL. An EOL at/before the current cycle is a state,
    # not a negative remaining-life prediction.
    if current_soh <= threshold or (finite.any() and np.nanmedian(ruls[finite]) <= 0):
        return {"rul_median": 0.0, "rul_lower": 0.0, "rul_upper": 0.0,
                "eol_cycle_median": current_cycle, "rul_interval_width": 0.0,
                "rul_status": "already_below_threshold", "rul_valid": False,
                "current_soh_pred": current_soh,
                "valid_sample_fraction": float(finite.mean()),
                "rul_horizon_limit": horizon_limit}
    valid = finite & (ruls >= 0) & (ruls <= horizon_limit)
    valid_fraction = float(valid.mean())
    if valid_fraction < float(min_valid_sample_fraction):
        reason = "not_estimable_abnormal_extrapolation" if finite.any() else "not_estimable_no_threshold_or_negative_slope"
        return _empty(reason, current_soh, horizon_limit, valid_fraction)
    ruls, crossings = ruls[valid], crossings[valid]
    lower, median, upper = (float(np.quantile(ruls, q)) for q in (.025, .5, .975))
    width = upper - lower
    if width > float(max_interval_width_cycles):
        return _empty("not_estimable_interval_too_wide", current_soh, horizon_limit, valid_fraction)
    return {"rul_median": median, "rul_lower": lower, "rul_upper": upper,
            "eol_cycle_median": float(np.median(crossings)), "rul_interval_width": width,
            "rul_status": "valid", "rul_valid": True,
            "current_soh_pred": current_soh, "valid_sample_fraction": valid_fraction,
            "rul_horizon_limit": horizon_limit}
