"""Build the screening interface from formal XGBoost leave-battery folds only."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import xgboost as xgb

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Noto Sans CJK SC", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rul import rul_from_samples


FOLD_DIRS = [f"xgboost_leave_battery_fold{i}" for i in range(5)]
FORCED_NOT_ESTIMABLE = {"XJTU:R2.5_battery-2", "XJTU:R2.5_battery-4"}
THRESHOLDS = (0.75, 0.80, 0.85)


def read_folds(results: Path):
    soh, rul, members, fold_metrics = [], [], [], []
    for fold, name in enumerate(FOLD_DIRS):
        run = results / name
        meta = json.loads((run / "metrics.json").read_text(encoding="utf-8"))
        if meta.get("run_stage") != "formal" or meta.get("split_mode") != "leave_battery" or meta.get("model") != "xgboost":
            raise ValueError(f"{name} is not a formal XGBoost leave-battery run")
        s = pd.read_csv(run / "soh_predictions.csv"); s["fold"] = fold; soh.append(s)
        r = pd.read_csv(run / "rul_intervals.csv"); r["fold"] = fold; rul.append(r)
        m = pd.read_csv(run / "soh_member_predictions.csv"); m["fold"] = fold; members.append(m)
        fold_metrics.append({"fold": fold, "test_group": meta["test_group"],
                             "test_records": meta["test_records"], **meta["metrics"]})
    return (pd.concat(soh, ignore_index=True), pd.concat(rul, ignore_index=True),
            pd.concat(members, ignore_index=True), pd.DataFrame(fold_metrics))


def build_team_input(soh: pd.DataFrame, rul: pd.DataFrame, max_width: float) -> pd.DataFrame:
    latest = soh.sort_values(["battery_id", "cycle"]).groupby("battery_id", as_index=False).tail(1)
    merged = latest.merge(rul, on=["dataset", "condition_id", "battery_id", "fold"], how="left")
    out = pd.DataFrame({
        "battery_id": merged["battery_id"],
        "condition_id": merged["condition_id"],
        "current_cycle": merged["cycle"].astype(int),
        "SOH_pred": merged["SOH_pred"], "SOH_lower": merged["SOH_lower"], "SOH_upper": merged["SOH_upper"],
        "RUL_pred": merged["rul_median"], "RUL_lower": merged["rul_lower"], "RUL_upper": merged["rul_upper"],
        "uncertainty_width": merged["rul_interval_width"],
        "prediction_valid": merged["rul_valid"].fillna(False).astype(bool),
        "prediction_status": merged["rul_status"].fillna("not_estimable_missing_rul"),
        "model_name": "xgboost",
    })
    numeric = ["SOH_pred", "SOH_lower", "SOH_upper", "RUL_pred", "RUL_lower", "RUL_upper"]
    complete = out[numeric].notna().all(axis=1)
    ordered = ((out.SOH_lower <= out.SOH_pred) & (out.SOH_pred <= out.SOH_upper) &
               (out.RUL_lower <= out.RUL_pred) & (out.RUL_pred <= out.RUL_upper))
    nonnegative = (out[["RUL_pred", "RUL_lower", "RUL_upper"]].fillna(0) >= 0).all(axis=1)
    width_ok = out.uncertainty_width.fillna(np.inf).le(max_width)
    forced = out.battery_id.isin(FORCED_NOT_ESTIMABLE)
    valid = out.prediction_valid & complete & ordered & nonnegative & width_ok & ~forced
    invalid_wide = out.prediction_valid & complete & ordered & nonnegative & ~width_ok
    out.loc[invalid_wide, "prediction_status"] = "not_estimable_interval_too_wide"
    out.loc[forced, "prediction_status"] = "not_estimable"
    out.loc[forced | invalid_wide, ["RUL_pred", "RUL_lower", "RUL_upper", "uncertainty_width"]] = np.nan
    out["prediction_valid"] = valid
    out.loc[valid, "prediction_status"] = "valid"
    out.loc[~valid & out.prediction_status.eq("valid"), "prediction_status"] = "not_estimable_quality_gate"
    below = out.prediction_status.eq("already_below_threshold")
    out.loc[below, ["RUL_pred", "RUL_lower", "RUL_upper", "uncertainty_width"]] = 0.0
    return out.sort_values(["condition_id", "battery_id"]).reset_index(drop=True)


def model_comparison(results: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    detail = pd.read_csv(results / "fold_metrics.csv")
    detail = detail[(detail.run_stage == "formal") & (detail.split_mode == "leave_battery")].copy()
    rows = []
    for model, g in detail.groupby("model"):
        rows.append({"model": model, "folds": len(g),
                     "MAE_mean": g.MAE.mean(), "MAE_std": g.MAE.std(ddof=1),
                     "RMSE_mean": g.RMSE.mean(), "RMSE_std": g.RMSE.std(ddof=1),
                     "MAPE_mean_pct": g.MAPE_pct.mean(), "MAPE_std_pct": g.MAPE_pct.std(ddof=1)})
    order = ["xgboost", "pinn", "lstm", "tcn", "mlp"]
    summary = pd.DataFrame(rows).set_index("model").loc[order].reset_index()
    return detail.sort_values(["model", "fold"]), summary


def feature_importance(results: Path) -> pd.DataFrame:
    accum = []
    feature_names = None
    for name in FOLD_DIRS:
        run = results / name
        manifest = json.loads((run / "model_manifest.json").read_text(encoding="utf-8"))
        feature_names = manifest["features"]
        for member in manifest["members"]:
            booster = xgb.Booster(); booster.load_model(run / member)
            score = booster.get_score(importance_type="gain")
            values = np.array([score.get(f"f{i}", score.get(feature, 0.0)) for i, feature in enumerate(feature_names)], float)
            accum.append(values / values.sum() if values.sum() else values)
    arr = np.asarray(accum)
    return pd.DataFrame({"feature": feature_names, "importance_mean": arr.mean(axis=0),
                         "importance_std": arr.std(axis=0, ddof=1)}).sort_values("importance_mean", ascending=False)


def sensitivity(members: pd.DataFrame, rul_cfg: dict) -> pd.DataFrame:
    member_cols = [c for c in members if c.startswith("SOH_member_")]
    rows = []
    for battery_id, g in members.sort_values("cycle").groupby("battery_id"):
        samples = g[member_cols].to_numpy(float).T
        for threshold in THRESHOLDS:
            info = rul_from_samples(g.cycle.to_numpy(), samples, threshold=threshold, **rul_cfg)
            rows.append({"battery_id": battery_id, "condition_id": g.condition_id.iloc[0],
                         "threshold": threshold, "current_cycle": int(g.cycle.iloc[-1]), **info})
    return pd.DataFrame(rows)


def save_figures(out: Path, soh: pd.DataFrame, rul: pd.DataFrame, comparison: pd.DataFrame,
                 importance: pd.DataFrame, threshold: pd.DataFrame):
    figures = out / "figures"; figures.mkdir(parents=True, exist_ok=True)
    plt.style.use("seaborn-v0_8-whitegrid")

    fig, axes = plt.subplots(1, 3, figsize=(12, 3.6))
    for ax, metric, label in zip(axes, ("MAE", "RMSE", "MAPE"), ("MAE", "RMSE", "MAPE (%)")):
        means = comparison[f"{metric}_mean" if metric != "MAPE" else "MAPE_mean_pct"]
        stds = comparison[f"{metric}_std" if metric != "MAPE" else "MAPE_std_pct"]
        ax.bar(comparison.model.str.upper(), means, yerr=stds, capsize=3, color="#3973ac")
        ax.set_ylabel(label); ax.tick_params(axis="x", rotation=35)
    fig.suptitle("五折留电池模型比较（误差棒为折间标准差）"); fig.tight_layout()
    fig.savefig(figures / "model_comparison.png", dpi=300, bbox_inches="tight"); plt.close(fig)

    fig, ax = plt.subplots(figsize=(5.4, 5.0))
    for cond, g in soh.groupby("condition_id"):
        ax.scatter(g.SOH, g.SOH_pred, s=5, alpha=.22, label=cond)
    lo = min(soh.SOH.min(), soh.SOH_pred.min()); hi = max(soh.SOH.max(), soh.SOH_pred.max())
    ax.plot([lo, hi], [lo, hi], "k--", lw=1); ax.set(xlabel="真实SOH", ylabel="预测SOH", title="XGBoost真实值与预测值对比")
    ax.legend(fontsize=7, ncol=2); fig.tight_layout(); fig.savefig(figures / "soh_true_vs_pred.png", dpi=300); plt.close(fig)

    battery_rmse = soh.assign(se=(soh.SOH-soh.SOH_pred)**2).groupby(["condition_id","battery_id"]).se.mean().pow(.5).reset_index()
    wanted = [c for c in ["2C", "3C", "R2.5", "RW", "Sim_satellite"] if c in set(battery_rmse.condition_id)]
    selected = []
    for cond in wanted:
        g = battery_rmse[battery_rmse.condition_id == cond].sort_values("se")
        selected.append(g.iloc[len(g)//2].battery_id)
    curves = soh[soh.battery_id.isin(selected)].copy()
    curves.to_csv(out / "representative_soh_curves.csv", index=False, encoding="utf-8-sig")
    fig, axes = plt.subplots(3, 2, figsize=(10, 10), sharey=True); axes = axes.ravel()
    for ax, (bid, g) in zip(axes, curves.groupby("battery_id", sort=False)):
        g = g.sort_values("cycle"); ax.plot(g.cycle, g.SOH, label="真实值", lw=1.5); ax.plot(g.cycle, g.SOH_pred, label="预测值", lw=1.2)
        ax.fill_between(g.cycle, g.SOH_lower, g.SOH_upper, alpha=.18); ax.axhline(.8, color="k", ls="--", lw=.8); ax.set_title(bid.replace("XJTU:", ""), fontsize=9); ax.set_xlabel("循环次数"); ax.set_ylabel("SOH")
    for ax in axes[len(selected):]: ax.axis("off")
    axes[0].legend(fontsize=8); fig.suptitle("代表性电芯的XGBoost SOH轨迹"); fig.tight_layout(); fig.savefig(figures / "representative_soh_curves.png", dpi=300); plt.close(fig)

    valid = rul[rul.rul_valid.astype(str).str.lower().isin(["true", "1"])].sort_values("rul_median")
    idx = np.linspace(0, len(valid)-1, min(5, len(valid))).round().astype(int); rep = valid.iloc[idx].drop_duplicates("battery_id")
    rep.to_csv(out / "representative_rul_intervals.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(7.5, 4.2)); y = np.arange(len(rep)); med = rep.rul_median.to_numpy(float)
    ax.errorbar(med, y, xerr=np.vstack([med-rep.rul_lower.to_numpy(float), rep.rul_upper.to_numpy(float)-med]), fmt="o", capsize=4)
    ax.set_yticks(y, rep.battery_id.str.replace("XJTU:", "", regex=False)); ax.set_xlabel("预测RUL/循环"); ax.set_title("代表性电芯的XGBoost RUL经验区间"); fig.tight_layout(); fig.savefig(figures / "rul_intervals.png", dpi=300); plt.close(fig)

    top = importance.head(15).sort_values("importance_mean")
    fig, ax = plt.subplots(figsize=(7.2, 5.5)); ax.barh(top.feature, top.importance_mean, xerr=top.importance_std, color="#3973ac", capsize=2); ax.set_xlabel("归一化增益重要度"); ax.set_title("XGBoost特征重要度（50个集成成员）"); fig.tight_layout(); fig.savefig(figures / "feature_importance.png", dpi=300); plt.close(fig)

    valid_t = threshold[threshold.rul_valid].copy()
    agg = valid_t.groupby("threshold").rul_median.agg(["median", lambda s: s.quantile(.25), lambda s: s.quantile(.75), "count"]).reset_index()
    agg.columns = ["threshold", "median", "q25", "q75", "valid_batteries"]
    agg.to_csv(out / "threshold_sensitivity_summary.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(6.2, 4.2)); ax.plot(agg.threshold, agg["median"], marker="o"); ax.fill_between(agg.threshold, agg.q25, agg.q75, alpha=.2); ax.set_xticks(THRESHOLDS); ax.set(xlabel="SOH失效阈值", ylabel="预测RUL中位数/循环", title="RUL对SOH阈值的敏感性"); fig.tight_layout(); fig.savefig(figures / "threshold_sensitivity.png", dpi=300); plt.close(fig)


def main():
    parser = argparse.ArgumentParser(); parser.add_argument("--root", required=True); parser.add_argument("--output", required=True)
    args = parser.parse_args(); root = Path(args.root).resolve(); results = root / "results"; out = Path(args.output).resolve(); out.mkdir(parents=True, exist_ok=True)
    cfg = json.loads((root / "configs" / "default.json").read_text(encoding="utf-8")); rul_cfg = dict(cfg["rul"]); max_width = float(rul_cfg["max_interval_width_cycles"]); rul_cfg.pop("threshold", None)
    soh, rul, members, xgb_folds = read_folds(results)
    interface = build_team_input(soh, rul, max_width); interface.to_csv(out / "battery_prediction_interface.csv", index=False, encoding="utf-8-sig")
    detail, comparison = model_comparison(results); comparison.to_csv(out / "model_comparison.csv", index=False, encoding="utf-8-sig")
    xgb_folds.to_csv(out / "xgboost_fold_metrics.csv", index=False, encoding="utf-8-sig")
    soh.to_csv(out / "soh_true_vs_pred.csv", index=False, encoding="utf-8-sig")
    importance = feature_importance(results); importance.to_csv(out / "feature_importance.csv", index=False, encoding="utf-8-sig")
    threshold = sensitivity(members, rul_cfg); threshold.to_csv(out / "threshold_sensitivity.csv", index=False, encoding="utf-8-sig")
    save_figures(out, soh, rul, comparison, importance, threshold)
    summary = {"rows": len(interface), "unique_batteries": int(interface.battery_id.nunique()), "valid": int(interface.prediction_valid.sum()),
               "status_counts": interface.prediction_status.value_counts().to_dict(), "source": "formal XGBoost leave-battery 5-fold only"}
    (out / "interface_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__": main()
