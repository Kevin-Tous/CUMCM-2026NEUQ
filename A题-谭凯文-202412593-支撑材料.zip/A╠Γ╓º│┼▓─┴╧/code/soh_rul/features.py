"""Data adapters for the official 16-HI files and the cleaned condition table."""
from __future__ import annotations

from pathlib import Path
import re
import numpy as np
import pandas as pd

HI16 = [
    "voltage mean", "voltage std", "voltage kurtosis", "voltage skewness",
    "CC Q", "CC charge time", "voltage slope", "voltage entropy",
    "current mean", "current std", "current kurtosis", "current skewness",
    "CV Q", "CV charge time", "current slope", "current entropy",
]
CONDITION_FEATURES = ["temperature_C", "charge_rate_C", "discharge_rate_C", "DOD", "EFC"]


def infer_condition(file_name: str) -> dict[str, float]:
    """Parse XJTU group names conservatively; unknown values remain NaN."""
    name = Path(file_name).stem
    charge = np.nan
    discharge = np.nan
    dod = 1.0
    if name.startswith("2C_"):
        charge, discharge = 2.0, 1.0
    elif name.startswith("3C_"):
        charge, discharge = 3.0, 1.0
    elif name.startswith("R2.5_"):
        charge, discharge = 2.5, 1.0
    elif name.startswith("R3_"):
        charge, discharge = 3.0, 1.0
    return {"temperature_C": np.nan, "charge_rate_C": charge,
            "discharge_rate_C": discharge, "DOD": dod}


def load_official_directory(root: str | Path, dataset: str = "XJTU") -> pd.DataFrame:
    rows = []
    root = Path(root)
    for path in sorted(root.rglob("*.csv")):
        frame = pd.read_csv(path)
        missing = [c for c in HI16 + ["capacity"] if c not in frame]
        if missing:
            raise ValueError(f"{path.name} missing official columns: {missing}")
        frame = frame[HI16 + ["capacity"]].replace([np.inf, -np.inf], np.nan).dropna()
        frame.insert(0, "cycle", np.arange(1, len(frame) + 1, dtype=int))
        relative_id = path.relative_to(root).with_suffix("").as_posix()
        frame.insert(0, "battery_id", f"{dataset}:{relative_id}")
        condition = re.sub(r"_?battery-?\d+$", "", path.stem, flags=re.I) if dataset.upper() == "XJTU" else path.parent.name
        frame.insert(0, "condition_id", condition)
        frame.insert(0, "dataset", dataset)
        nominal = 2.0 if dataset.upper() == "XJTU" else float(frame["capacity"].iloc[0])
        frame["SOH"] = frame["capacity"] / nominal
        cond = infer_condition(path.name) if dataset.upper() == "XJTU" else {}
        for key in ["temperature_C", "charge_rate_C", "discharge_rate_C", "DOD"]:
            frame[key] = cond.get(key, np.nan)
        frame["EFC"] = frame["cycle"] * frame["DOD"].fillna(1.0)
        rows.append(frame)
    if not rows:
        raise FileNotFoundError(f"No CSV files under {root}")
    return pd.concat(rows, ignore_index=True)


def merge_cleaned_conditions(frame: pd.DataFrame, condition_csv: str | Path) -> pd.DataFrame:
    """Fill condition variables from the leak-safe XJTU table by source file and cycle."""
    c = pd.read_csv(condition_csv)
    c["stem"] = c["source_file"].astype(str).map(lambda x: Path(x).stem)
    c["battery_id"] = "XJTU:" + c["stem"]
    keep = ["battery_id", "cycle", "mean_temperature_C", "charge_rate_C",
            "discharge_rate_C", "DOD_proxy"]
    c = c[keep].drop_duplicates(["battery_id", "cycle"])
    c = c.rename(columns={"mean_temperature_C": "temperature_C_clean",
                          "charge_rate_C": "charge_rate_C_clean",
                          "discharge_rate_C": "discharge_rate_C_clean",
                          "DOD_proxy": "DOD_clean"})
    out = frame.merge(c, on=["battery_id", "cycle"], how="left")
    for name in ["temperature_C", "charge_rate_C", "discharge_rate_C", "DOD"]:
        clean = f"{name}_clean"
        if clean in out:
            out[name] = out[clean].combine_first(out[name])
            out = out.drop(columns=clean)
    out["EFC"] = out["cycle"] * out["DOD"].fillna(1.0)
    return out


def prepare_matrix(frame: pd.DataFrame, include_conditions: bool = True):
    cols = HI16 + (["cycle"] + CONDITION_FEATURES if include_conditions else ["cycle"])
    x = frame[cols].astype(float).copy()
    return x.to_numpy(np.float32), frame["SOH"].to_numpy(np.float32), cols


def fit_preprocessor(x: np.ndarray, train_indices: np.ndarray):
    """Fit imputation and scaling on training rows only, then transform all rows."""
    train = np.asarray(x[train_indices], float)
    medians = np.array([np.median(col[np.isfinite(col)]) if np.isfinite(col).any() else 0.0
                        for col in train.T], dtype=float)
    filled = np.where(np.isfinite(x), x, medians)
    mean = filled[train_indices].mean(axis=0)
    std = filled[train_indices].std(axis=0)
    std = np.where(std > 1e-8, std, 1.0)
    return ((filled - mean) / std).astype(np.float32), {
        "median": medians.tolist(), "mean": mean.tolist(), "std": std.tolist()}
