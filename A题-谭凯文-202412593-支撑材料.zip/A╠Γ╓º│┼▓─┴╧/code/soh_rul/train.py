"""Unified CLI for XGBoost, MLP, LSTM, TCN and enhanced PINN experiments."""
from __future__ import annotations
import argparse, json, random, sys
from pathlib import Path
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from features import load_official_directory, merge_cleaned_conditions, prepare_matrix, fit_preprocessor
from splits import make_split
from rul import rul_from_samples


def resolve(config_file: Path, value: str) -> Path:
    p = Path(value)
    return p if p.is_absolute() else (config_file.parent / p).resolve()


def metrics(y, p):
    e = np.asarray(p) - np.asarray(y)
    return {"MAE": float(np.mean(np.abs(e))), "RMSE": float(np.sqrt(np.mean(e * e))),
            "MAPE_pct": float(np.mean(np.abs(e) / np.maximum(np.abs(y), 1e-6)) * 100)}


def sequence_windows(frame, x, y, length):
    xs, ys, row_ids = [], [], []
    for _, ids in frame.groupby("battery_id", sort=False).groups.items():
        ids = np.asarray(list(ids), int)
        for j in range(length - 1, len(ids)):
            xs.append(x[ids[j-length+1:j+1]])
            ys.append(y[ids[j]])
            row_ids.append(ids[j])
    return np.asarray(xs, np.float32), np.asarray(ys, np.float32), np.asarray(row_ids, int)


def mc_predict(model, tensor, passes):
    import torch
    model.train()  # enable dropout, while gradients remain disabled
    with torch.no_grad():
        return np.stack([model(tensor).cpu().numpy() for _ in range(passes)])


def select_device(requested):
    import torch
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if requested == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("--device cuda was requested, but torch.cuda.is_available() is False")
    return torch.device(requested)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--model", choices=["xgboost", "mlp", "lstm", "tcn", "pinn"], required=True)
    ap.add_argument("--split", choices=["leave_battery", "leave_condition", "cross_dataset"], default="leave_battery")
    ap.add_argument("--fold", type=int, default=0)
    ap.add_argument("--n-folds", type=int, default=None,
                    help="number of leakage-safe grouped CV folds")
    ap.add_argument("--quick", action="store_true", help="two-epoch integration check")
    ap.add_argument("--device", choices=["auto", "cuda", "cpu"], default="auto",
                    help="compute device; auto selects CUDA when available")
    args = ap.parse_args()
    config_file = Path(args.config).resolve()
    cfg = json.loads(config_file.read_text(encoding="utf-8"))
    seed = int(cfg["training"]["seed"])
    random.seed(seed); np.random.seed(seed)

    sources = cfg["data"]["sources"] if args.split == "cross_dataset" else {"XJTU": cfg["data"]["sources"]["XJTU"]}
    frames = [load_official_directory(resolve(config_file, path), name) for name, path in sources.items()]
    frame = pd.concat(frames, ignore_index=True)
    condition_csv = resolve(config_file, cfg["data"]["clean_condition_csv"])
    if condition_csv.exists() and "XJTU" in frame["dataset"].unique():
        xjtu = merge_cleaned_conditions(frame[frame.dataset == "XJTU"], condition_csv)
        frame = pd.concat([xjtu, frame[frame.dataset != "XJTU"]], ignore_index=True)
    frame = frame.sort_values(["dataset", "battery_id", "cycle"]).reset_index(drop=True)
    x, y, feature_names = prepare_matrix(frame, cfg["data"]["include_conditions"])
    tr, va, te, split_info = make_split(frame, args.split, args.fold, args.n_folds)
    x, preprocessing = fit_preprocessor(x, tr)

    stage_suffix = "_quick" if args.quick else ""
    out = resolve(config_file, cfg["output_dir"]) / f"{args.model}_{args.split}_fold{args.fold}{stage_suffix}"
    out.mkdir(parents=True, exist_ok=True)
    pred_samples = None
    device_used = "cpu"

    if args.model == "xgboost":
        import xgboost
        from xgboost import XGBRegressor
        device = select_device(args.device)
        device_used = device.type
        print(f"Using device: {device_used} (XGBoost)", flush=True)
        ensemble = []
        member_files = []
        for k in range(cfg["uncertainty"]["ensemble_size"]):
            model = XGBRegressor(n_estimators=30 if args.quick else cfg["xgboost"]["n_estimators"],
                max_depth=cfg["xgboost"]["max_depth"], learning_rate=cfg["xgboost"]["learning_rate"],
                subsample=.85, colsample_bytree=.85, random_state=seed+k, n_jobs=-1,
                tree_method="hist", device=device_used)
            model.fit(x[tr], y[tr])
            # Training uses CUDA; NumPy test features reside on the CPU, so use
            # CPU inference to avoid an unnecessary device-mismatch copy/warning.
            if device_used == "cuda":
                model.get_booster().set_param({"device": "cpu"})
            member_name = f"xgboost_member_{k:02d}.ubj"
            model.save_model(str(out / member_name))
            member_files.append(member_name)
            ensemble.append(model.predict(x[te]))
        pred_samples = np.stack(ensemble)
        preprocessing_artifact = {
            "features": feature_names,
            "median": preprocessing["median"],
            "mean": preprocessing["mean"],
            "std": preprocessing["std"],
        }
        (out / "preprocessing.json").write_text(
            json.dumps(preprocessing_artifact, ensure_ascii=False, indent=2), encoding="utf-8")
        manifest = {
            "model_type": "XGBRegressor ensemble",
            "serialization": "XGBoost UBJ",
            "xgboost_version": xgboost.__version__,
            "training_device": device_used,
            "ensemble_size": len(member_files),
            "members": member_files,
            "preprocessing_file": "preprocessing.json",
            "features": feature_names,
            "seed_start": seed,
            "seeds": [seed + k for k in range(len(member_files))],
            "parameters": {
                "n_estimators": 30 if args.quick else cfg["xgboost"]["n_estimators"],
                "max_depth": cfg["xgboost"]["max_depth"],
                "learning_rate": cfg["xgboost"]["learning_rate"],
                "subsample": 0.85,
                "colsample_bytree": 0.85,
                "tree_method": "hist",
            },
        }
        (out / "model_manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    else:
        import torch
        from torch.utils.data import DataLoader, TensorDataset
        from models import MLP, LSTM, TCN, PhysicsInformedMLP, physics_loss
        torch.manual_seed(seed)
        device = select_device(args.device)
        device_used = device.type
        if device.type == "cuda":
            torch.cuda.manual_seed_all(seed)
            torch.backends.cudnn.benchmark = True
            # PyTorch 2.11 + CUDA 12.8 on this Windows environment can finish
            # cuDNN LSTM training successfully and then abort during DLL
            # teardown with 0xC0000409.  The native CUDA LSTM path is stable
            # and still trains on the GPU, so only disable cuDNN for LSTM.
            if args.model == "lstm":
                torch.backends.cudnn.enabled = False
        print(f"Using device: {device} (PyTorch)", flush=True)
        length = cfg["training"]["sequence_length"] if args.model in {"lstm", "tcn"} else 1
        if length > 1:
            wx, wy, rows = sequence_windows(frame, x, y, length)
            trm, vam, tem = np.isin(rows, tr), np.isin(rows, va), np.isin(rows, te)
            xtr, ytr, xte, yte, test_rows = wx[trm], wy[trm], wx[tem], wy[tem], rows[tem]
        else:
            xtr, ytr, xte, yte, test_rows = x[tr], y[tr], x[te], y[te], te
        classes = {"mlp": MLP, "lstm": LSTM, "tcn": TCN, "pinn": PhysicsInformedMLP}
        model = classes[args.model](x.shape[1], dropout=cfg["training"]["dropout"]).to(device)
        opt = torch.optim.AdamW(model.parameters(), lr=cfg["training"]["learning_rate"], weight_decay=1e-5)
        all_codes = pd.factorize(frame["battery_id"])[0]
        train_rows = tr if length == 1 else rows[trm]
        ds = TensorDataset(torch.as_tensor(xtr, dtype=torch.float32),
                           torch.as_tensor(ytr, dtype=torch.float32),
                           torch.tensor(all_codes[train_rows], dtype=torch.long),
                           torch.tensor(frame.loc[train_rows, "cycle"].to_numpy(), dtype=torch.long))
        loader = DataLoader(ds, batch_size=cfg["training"]["batch_size"],
                            shuffle=args.model != "pinn", pin_memory=device.type == "cuda")
        epochs = 2 if args.quick else cfg["training"]["epochs"]
        for _ in range(epochs):
            model.train()
            for xb, yb, codes, cycles in loader:
                xb = xb.to(device, non_blocking=True)
                yb = yb.to(device, non_blocking=True)
                codes = codes.to(device, non_blocking=True)
                cycles = cycles.to(device, non_blocking=True)
                pred = model(xb)
                if args.model == "pinn":
                    loss, _ = physics_loss(model, xb, yb, pred, codes, cycles, cfg["physics_loss"])
                else:
                    loss = torch.nn.functional.mse_loss(pred, yb)
                opt.zero_grad(); loss.backward(); opt.step()
        xt = torch.as_tensor(xte, dtype=torch.float32, device=device)
        pred_samples = mc_predict(model, xt, cfg["uncertainty"]["mc_passes"])
        y = yte; te = test_rows
        state_dict = {name: value.detach().cpu() for name, value in model.state_dict().items()}
        torch.save({"model": state_dict, "features": feature_names,
                    "preprocessing": preprocessing}, out / "model.pt")

    pred = np.median(pred_samples, axis=0)
    result = frame.iloc[te][["dataset", "condition_id", "battery_id", "cycle", "SOH"]].copy()
    result["SOH_pred"] = pred
    result["SOH_lower"] = np.quantile(pred_samples, .025, axis=0)
    result["SOH_upper"] = np.quantile(pred_samples, .975, axis=0)
    result.to_csv(out / "soh_predictions.csv", index=False, encoding="utf-8-sig")
    if args.model == "xgboost":
        member_result = result[["dataset", "condition_id", "battery_id", "cycle", "SOH"]].copy()
        for k, values in enumerate(pred_samples):
            member_result[f"SOH_member_{k:02d}"] = values
        member_result.to_csv(out / "soh_member_predictions.csv", index=False, encoding="utf-8-sig")
    rul_rows = []
    for bid, g in result.sort_values("cycle").groupby("battery_id"):
        positions = g.index.to_numpy()
        local = result.index.get_indexer(positions)
        # locate predictions by row membership, independent of original frame index
        mask = result["battery_id"].eq(bid).to_numpy()
        info = rul_from_samples(g["cycle"].to_numpy(), pred_samples[:, mask], **cfg["rul"])
        rul_rows.append({"battery_id": bid, "dataset": g["dataset"].iloc[0],
                         "condition_id": g["condition_id"].iloc[0], **info})
    pd.DataFrame(rul_rows).to_csv(out / "rul_intervals.csv", index=False, encoding="utf-8-sig")
    report = {"model": args.model, "run_stage": "quick" if args.quick else "formal", **split_info, "features": feature_names,
              "test_records": int(len(result)), "metrics": metrics(result["SOH"], result["SOH_pred"]),
              "uncertainty": "ensemble" if args.model == "xgboost" else "MC Dropout",
              "device": device_used}
    (out / "metrics.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__": main()
