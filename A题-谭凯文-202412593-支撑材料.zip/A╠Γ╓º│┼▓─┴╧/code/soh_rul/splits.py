"""Leakage-safe split definitions."""
from __future__ import annotations
import numpy as np


def make_split(frame, mode="leave_battery", fold=0, n_folds=None):
    key = {"leave_battery": "battery_id", "leave_condition": "condition_id",
           "cross_dataset": "dataset"}[mode]
    groups = sorted(frame[key].dropna().astype(str).unique())
    if len(groups) < 2:
        raise ValueError(f"{mode} requires at least two {key} groups")
    if n_folds is not None:
        n_folds = int(n_folds)
        if n_folds < 3:
            raise ValueError("grouped cross-validation requires at least 3 folds (train/validation/test)")
        if n_folds > len(groups):
            raise ValueError(f"{mode} has only {len(groups)} groups, cannot create {n_folds} folds")
        fold = int(fold)
        if not 0 <= fold < n_folds:
            raise ValueError(f"fold must be in [0, {n_folds - 1}], got {fold}")
        partitions = [list(x) for x in np.array_split(np.asarray(groups, dtype=object), n_folds)]
        test_groups = partitions[fold]
        val_groups = partitions[(fold + 1) % n_folds]
        values = frame[key].astype(str)
        test = values.isin(test_groups).to_numpy()
        val = values.isin(val_groups).to_numpy()
        train = ~(test | val)
        return np.flatnonzero(train), np.flatnonzero(val), np.flatnonzero(test), {
            "split_mode": mode, "fold": fold, "n_folds": n_folds,
            "test_group": ";".join(test_groups),
            "validation_group": ";".join(val_groups)}
    test_group = groups[fold % len(groups)]
    test = frame[key].astype(str).eq(test_group).to_numpy()
    remaining = [g for g in groups if g != test_group]
    val_group = remaining[fold % len(remaining)]
    val = frame[key].astype(str).eq(val_group).to_numpy()
    train = ~(test | val)
    return np.flatnonzero(train), np.flatnonzero(val), np.flatnonzero(test), {
        "split_mode": mode, "fold": int(fold), "n_folds": None,
        "test_group": test_group, "validation_group": val_group}
