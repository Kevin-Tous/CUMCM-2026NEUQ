"""Neural baselines and enhanced physics-informed loss."""
from __future__ import annotations
import torch
from torch import nn
import torch.nn.functional as F


class MLP(nn.Module):
    def __init__(self, n_features, hidden=96, dropout=0.15):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(n_features, hidden), nn.SiLU(), nn.Dropout(dropout),
                                 nn.Linear(hidden, hidden), nn.SiLU(), nn.Dropout(dropout),
                                 nn.Linear(hidden, 1))
    def forward(self, x): return self.net(x).squeeze(-1)


class LSTM(nn.Module):
    def __init__(self, n_features, hidden=64, dropout=0.15):
        super().__init__()
        self.rnn = nn.LSTM(n_features, hidden, num_layers=2, batch_first=True, dropout=dropout)
        self.drop = nn.Dropout(dropout)
        self.head = nn.Linear(hidden, 1)
    def forward(self, x):
        if x.ndim == 2: x = x[:, None, :]
        y, _ = self.rnn(x)
        return self.head(self.drop(y[:, -1])).squeeze(-1)


class TCN(nn.Module):
    def __init__(self, n_features, hidden=64, dropout=0.15):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(n_features, hidden, 3, padding=2, dilation=1), nn.SiLU(), nn.Dropout(dropout),
            nn.Conv1d(hidden, hidden, 3, padding=4, dilation=2), nn.SiLU(), nn.Dropout(dropout))
        self.head = nn.Linear(hidden, 1)
    def forward(self, x):
        if x.ndim == 2: x = x[:, None, :]
        z = self.net(x.transpose(1, 2))[:, :, :x.shape[1]]
        return self.head(z[:, :, -1]).squeeze(-1)


class PhysicsInformedMLP(MLP):
    """Solution network plus learned degradation-rate network."""
    def __init__(self, n_features, hidden=96, dropout=0.15):
        super().__init__(n_features, hidden, dropout)
        self.rate = nn.Sequential(nn.Linear(n_features + 1, hidden), nn.SiLU(),
                                  nn.Linear(hidden, 1))


def physics_loss(model, x, y, pred, battery_codes, cycles, weights):
    order = torch.argsort(battery_codes * (cycles.max().long() + 2) + cycles.long())
    p, yy, xx, bb = pred[order], y[order], x[order], battery_codes[order]
    same = bb[1:] == bb[:-1]
    dp = p[1:] - p[:-1]
    monotonic = F.relu(dp[same] - weights.get("regen_tolerance", 0.002)).mean() if same.any() else p.new_tensor(0.)
    d2 = dp[1:] - dp[:-1]
    same3 = same[1:] & same[:-1]
    smooth = d2[same3].square().mean() if same3.any() else p.new_tensor(0.)
    if hasattr(model, "rate"):
        rate = model.rate(torch.cat([xx[:-1], p[:-1, None]], dim=1)).squeeze(-1)
        dynamics = (dp[same] - rate[same]).square().mean() if same.any() else p.new_tensor(0.)
    else:
        dynamics = p.new_tensor(0.)
    data = F.mse_loss(pred, y)
    total = data + weights["monotonic"] * monotonic + weights["smooth"] * smooth + weights["dynamics"] * dynamics
    return total, {"data": data.detach(), "monotonic": monotonic.detach(),
                   "smooth": smooth.detach(), "dynamics": dynamics.detach()}
