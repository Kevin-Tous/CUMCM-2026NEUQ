"""Collect fold metrics and produce statistically meaningful model summaries."""
from __future__ import annotations
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def collect(results: Path) -> pd.DataFrame:
    rows = []
    for path in sorted(results.glob("*/metrics.json")):
        meta = json.loads(path.read_text(encoding="utf-8"))
        metrics = meta.get("metrics", {})
        rows.append({
            "run_name": path.parent.name,
            "model": meta.get("model"),
            "split_mode": meta.get("split_mode"),
            "fold": meta.get("fold"),
            "n_folds": meta.get("n_folds"),
            "run_stage": meta.get("run_stage"),
            "device": meta.get("device"),
            "test_group": meta.get("test_group"),
            "validation_group": meta.get("validation_group"),
            "test_records": meta.get("test_records", 0),
            "MAE": metrics.get("MAE"),
            "RMSE": metrics.get("RMSE"),
            "MAPE_pct": metrics.get("MAPE_pct"),
        })
    return pd.DataFrame(rows)


def summarize(group: pd.DataFrame) -> pd.Series:
    n = group["test_records"].astype(float).to_numpy()
    total = n.sum()
    weights = n / total if total else np.full(len(group), 1 / len(group))
    rmse = group["RMSE"].astype(float).to_numpy()
    return pd.Series({
        "folds_completed": int(len(group)),
        "test_records_total": int(total),
        "MAE_mean": float(group["MAE"].mean()),
        "MAE_std": float(group["MAE"].std(ddof=1)) if len(group) > 1 else 0.0,
        "MAE_weighted": float(np.sum(weights * group["MAE"].astype(float))),
        "RMSE_mean": float(group["RMSE"].mean()),
        "RMSE_std": float(group["RMSE"].std(ddof=1)) if len(group) > 1 else 0.0,
        "RMSE_pooled": float(np.sqrt(np.sum(weights * rmse * rmse))),
        "RMSE_worst_fold": float(group["RMSE"].max()),
        "MAPE_mean_pct": float(group["MAPE_pct"].mean()),
        "MAPE_std_pct": float(group["MAPE_pct"].std(ddof=1)) if len(group) > 1 else 0.0,
        "MAPE_weighted_pct": float(np.sum(weights * group["MAPE_pct"].astype(float))),
    })


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", required=True)
    args = parser.parse_args()
    results = Path(args.results).resolve()
    detail = collect(results)
    if detail.empty:
        raise RuntimeError(f"no metrics.json files found below {results}")
    detail = detail.sort_values(["run_stage", "split_mode", "model", "fold"], na_position="last")
    detail.to_csv(results / "fold_metrics.csv", index=False, encoding="utf-8-sig")
    cv = detail[detail["n_folds"].notna()].copy()
    if cv.empty:
        raise RuntimeError("no grouped multi-fold results found; run the multi-fold benchmark first")
    summary = (cv.groupby(["run_stage", "split_mode", "model"], dropna=False)
                 .apply(summarize, include_groups=False).reset_index())
    summary.to_csv(results / "model_summary.csv", index=False, encoding="utf-8-sig")
    payload = {
        "runs_collected": int(len(detail)),
        "multifold_runs": int(len(cv)),
        "summary_rows": int(len(summary)),
        "stages": sorted(detail.run_stage.dropna().astype(str).unique().tolist()),
    }
    (results / "fold_summary.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
