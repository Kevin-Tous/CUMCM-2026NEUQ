"""Five-fold XGBoost ablation for 16HI, +cycle, and +condition features."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from xgboost import XGBRegressor

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from features import HI16, CONDITION_FEATURES, load_official_directory, merge_cleaned_conditions, fit_preprocessor
from splits import make_split


def metric(y, pred):
    err = np.asarray(pred)-np.asarray(y)
    return {"MAE": float(np.mean(np.abs(err))), "RMSE": float(np.sqrt(np.mean(err**2))),
            "MAPE_pct": float(np.mean(np.abs(err)/np.maximum(np.abs(y), 1e-6))*100)}


def resolve(config: Path, value: str):
    p = Path(value); return p if p.is_absolute() else (config.parent/p).resolve()


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--root", required=True); ap.add_argument("--output", required=True); ap.add_argument("--device", default="cuda")
    args = ap.parse_args(); root=Path(args.root).resolve(); out=Path(args.output).resolve(); out.mkdir(parents=True,exist_ok=True)
    config_file=root/"configs"/"default.json"; cfg=json.loads(config_file.read_text(encoding="utf-8")); seed=int(cfg["training"]["seed"])
    frame=load_official_directory(resolve(config_file,cfg["data"]["sources"]["XJTU"]),"XJTU")
    condition=resolve(config_file,cfg["data"]["clean_condition_csv"])
    if condition.exists(): frame=merge_cleaned_conditions(frame,condition)
    frame=frame.sort_values(["dataset","battery_id","cycle"]).reset_index(drop=True)
    y=frame.SOH.to_numpy(np.float32)
    # Keep machine-readable variant keys stable; translate only the plot labels.
    variants={"16HI":HI16,"16HI+cycle":HI16+["cycle"],"16HI+cycle+conditions":HI16+["cycle"]+CONDITION_FEATURES}
    rows=[]
    for variant,cols in variants.items():
        raw=frame[cols].astype(float).to_numpy(np.float32)
        for fold in range(5):
            tr,va,te,info=make_split(frame,"leave_battery",fold,5); x,_=fit_preprocessor(raw,tr); preds=[]
            print(f"Running {variant} / fold {fold} of 5",flush=True)
            for k in range(cfg["uncertainty"]["ensemble_size"]):
                model=XGBRegressor(n_estimators=cfg["xgboost"]["n_estimators"],max_depth=cfg["xgboost"]["max_depth"],
                    learning_rate=cfg["xgboost"]["learning_rate"],subsample=.85,colsample_bytree=.85,
                    random_state=seed+k,n_jobs=-1,tree_method="hist",device=args.device)
                model.fit(x[tr],y[tr]); model.get_booster().set_param({"device":"cpu"}); preds.append(model.predict(x[te]))
            pred=np.median(np.stack(preds),axis=0)
            rows.append({"variant":variant,"fold":fold,"features":len(cols),"test_records":len(te),"test_group":info["test_group"],**metric(y[te],pred)})
    detail=pd.DataFrame(rows); detail.to_csv(out/"xgboost_ablation_fold_metrics.csv",index=False,encoding="utf-8-sig")
    summary=detail.groupby(["variant","features"]).agg(folds=("fold","count"),MAE_mean=("MAE","mean"),MAE_std=("MAE","std"),RMSE_mean=("RMSE","mean"),RMSE_std=("RMSE","std"),MAPE_mean_pct=("MAPE_pct","mean"),MAPE_std_pct=("MAPE_pct","std")).reset_index()
    order=list(variants); summary["_order"]=summary.variant.map({v:i for i,v in enumerate(order)}); summary=summary.sort_values("_order").drop(columns="_order")
    summary.to_csv(out/"xgboost_ablation_summary.csv",index=False,encoding="utf-8-sig")
    plt.style.use("seaborn-v0_8-whitegrid")
    plt.rcParams["font.sans-serif"]=["Microsoft YaHei","SimHei","Noto Sans CJK SC","DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"]=False
    display=summary.variant.map({"16HI":"16HI","16HI+cycle":"16HI+循环","16HI+cycle+conditions":"16HI+循环+工况"})
    fig,axes=plt.subplots(1,2,figsize=(9,3.8))
    for ax,m in zip(axes,("MAE","RMSE")):
        ax.bar(display,summary[f"{m}_mean"],yerr=summary[f"{m}_std"],capsize=3,color="#3973ac"); ax.set_ylabel(m); ax.tick_params(axis="x",rotation=15); ax.set_title(f"五折{m}（越低越好）")
    fig.suptitle("XGBoost输入消融（误差棒为折间标准差）"); fig.tight_layout(); (out/"figures").mkdir(exist_ok=True); fig.savefig(out/"figures"/"ablation_comparison.png",dpi=300,bbox_inches="tight"); plt.close(fig)
    print(summary.to_string(index=False))


if __name__=="__main__": main()
