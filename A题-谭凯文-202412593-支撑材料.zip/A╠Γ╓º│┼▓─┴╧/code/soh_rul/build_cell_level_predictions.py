"""Build a safety-gated one-cell-per-row prediction interface."""
from __future__ import annotations
from pathlib import Path
import json
import argparse
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve()
PACKAGE_ROOT = HERE.parents[3]
ENHANCED_ROOT = HERE.parents[1]
RESULTS_ROOT = ENHANCED_ROOT / "results"


def canonical_id(dataset, battery_id):
    dataset, battery_id = str(dataset), str(battery_id)
    prefix = f"{dataset}:"
    rest = battery_id[len(prefix):] if battery_id.startswith(prefix) else battery_id
    data_prefix = f"{dataset} data/"
    if rest.startswith(data_prefix):
        rest = rest[len(data_prefix):]
    return f"{dataset}:{rest}"


def as_bool(series):
    return series.astype(str).str.lower().isin({"true", "1", "yes"})


def load_base_cells(clean_root: Path):
    main = pd.read_csv(clean_root / "main_soh_dataset_clean.csv")
    main = main.sort_values(["battery_id", "cycle"])
    latest = main.groupby("battery_id", as_index=False).tail(1).copy()
    latest["canonical_id"] = [canonical_id(d, b) for d, b in zip(latest.dataset, latest.battery_id)]
    labels = pd.read_csv(clean_root / "rul_labels_with_censoring.csv",
                         usecols=["dataset", "battery_id", "right_censored_at_80pct"])
    labels["canonical_id"] = [canonical_id(d, b) for d, b in zip(labels.dataset, labels.battery_id)]
    censored = labels.groupby("canonical_id")["right_censored_at_80pct"].agg(lambda s: bool(as_bool(s).any()))
    latest["right_censored"] = latest["canonical_id"].map(censored).fillna(False).astype(bool)
    return latest


def load_candidates():
    rows = []
    for metrics_file in sorted(RESULTS_ROOT.glob("*/metrics.json")):
        run_dir = metrics_file.parent
        soh_file, rul_file = run_dir / "soh_predictions.csv", run_dir / "rul_intervals.csv"
        if not soh_file.exists() or not rul_file.exists():
            continue
        meta = json.loads(metrics_file.read_text(encoding="utf-8"))
        soh = pd.read_csv(soh_file).sort_values(["battery_id", "cycle"]).groupby("battery_id", as_index=False).tail(1)
        rul = pd.read_csv(rul_file)
        merged = soh.merge(rul, on=[c for c in ["battery_id", "dataset", "condition_id"] if c in soh and c in rul], how="left", suffixes=("", "_rul"))
        for _, r in merged.iterrows():
            dataset = r.get("dataset", r.get("dataset_rul", "unknown"))
            rows.append({
                "canonical_id": canonical_id(dataset, r["battery_id"]), "dataset": dataset,
                "battery_id_result": r["battery_id"], "current_cycle": r["cycle"],
                "SOH_pred": r["SOH_pred"], "SOH_lower": r["SOH_lower"], "SOH_upper": r["SOH_upper"],
                "RUL_pred": r.get("rul_median", np.nan), "RUL_lower": r.get("rul_lower", np.nan),
                "RUL_upper": r.get("rul_upper", np.nan), "rul_status": r.get("rul_status", "legacy_unclassified"),
                "rul_valid": bool(r.get("rul_valid", False)), "run_stage": meta.get("run_stage", "legacy_quick"),
                "model_name": meta["model"], "split_mode": meta["split_mode"], "run_name": run_dir.name,
                "run_rmse": meta.get("metrics", {}).get("RMSE", np.nan),
            })
    return pd.DataFrame(rows)


def aggregate_candidate(group, right_censored):
    models = sorted(group.model_name.astype(str).unique())
    formal = group.run_stage.eq("formal")
    in_domain = ~group.split_mode.eq("cross_dataset")
    usable = group[formal & in_domain & group.rul_valid.fillna(False)]
    status = "valid"; reason = "formal_in_domain_prediction"
    if group.rul_status.astype(str).eq("already_below_threshold").all():
        status, reason = "already_below_threshold", "predicted_eol_not_after_current_cycle"
        usable = group.iloc[:0]
    elif not formal.any():
        status, reason = "not_estimable", "quick_validation_only"
    elif not in_domain.any():
        status, reason = "out_of_distribution", "cross_dataset_prediction_requires_review"
    elif not group.rul_valid.fillna(False).any():
        status, reason = "not_estimable", "rul_extrapolation_failed_quality_gate"
    elif right_censored:
        status, reason = "right_censored", "observed_eol_not_available"
    pick = usable if len(usable) else group
    soh_pred = float(np.nanmedian(pick.SOH_pred)) if pick.SOH_pred.notna().any() else np.nan
    soh_lower = float(np.nanmin(pick.SOH_lower)) if pick.SOH_lower.notna().any() else np.nan
    soh_upper = float(np.nanmax(pick.SOH_upper)) if pick.SOH_upper.notna().any() else np.nan
    if status == "already_below_threshold":
        rul_pred = rul_lower = rul_upper = 0.0
    elif len(usable):
        rul_pred = float(np.nanmedian(usable.RUL_pred)); rul_lower = float(np.nanmin(usable.RUL_lower)); rul_upper = float(np.nanmax(usable.RUL_upper))
    else:
        rul_pred = rul_lower = rul_upper = np.nan
    return {"SOH_pred": soh_pred, "SOH_lower": soh_lower, "SOH_upper": soh_upper,
            "RUL_pred": rul_pred, "RUL_lower": rul_lower, "RUL_upper": rul_upper,
            "uncertainty_width": (rul_upper-rul_lower) if np.isfinite(rul_upper) and np.isfinite(rul_lower) else np.nan,
            "prediction_valid": bool(status == "valid" and len(usable)), "prediction_status": status,
            "prediction_reason": reason, "model_name": "ensemble:" + "+".join(models) if len(models)>1 else models[0],
            "validation_stage": "formal" if formal.any() else "quick", "source_runs": ";".join(sorted(group.run_name.unique()))}


def add_uconn_rows(frame, path: Path | None):
    if path is None or not path.exists():
        return frame
    rpt = pd.read_csv(path).sort_values(["battery_id", "rpt_index"])
    first = rpt.groupby("battery_id", as_index=False).head(1).set_index("battery_id")
    last = rpt.groupby("battery_id", as_index=False).tail(1).copy()
    rows = []
    for _, r in last.iterrows():
        initial = first.loc[r.battery_id]
        dcir = np.nanmedian([r.DCIR_chg_median_mOhm, r.DCIR_dchg_median_mOhm])
        initial_dcir = np.nanmedian([initial.DCIR_chg_median_mOhm, initial.DCIR_dchg_median_mOhm])
        rows.append({"battery_id":r.battery_id,"dataset":r.dataset,"chemistry":"LFP/Graphite","current_cycle":r.rpt_index,
            "SOH_pred":r.SOH_C3,"SOH_lower":np.nan,"SOH_upper":np.nan,"RUL_pred":np.nan,"RUL_lower":np.nan,"RUL_upper":np.nan,
            "DCIR_mOhm":dcir,"DCIR_growth_ratio":dcir/initial_dcir-1 if initial_dcir>0 else np.nan,"uncertainty_width":np.nan,
            "right_censored":True,"prediction_valid":False,"prediction_status":"out_of_distribution",
            "prediction_reason":"LFP_cell_without_compatible_trained_RUL_model","model_name":"none",
            "validation_stage":"unmodeled","source_runs":"UConn_RPT_observation"})
    return pd.concat([frame, pd.DataFrame(rows)], ignore_index=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--clean-root", type=Path, required=True,
                        help="包含main_soh_dataset_clean.csv和rul_labels_with_censoring.csv的外部派生数据目录")
    parser.add_argument("--uconn-rpt", type=Path, default=None,
                        help="可选UConn派生RPT/DCIR表；最终包默认不依赖原始数据")
    parser.add_argument("--output", type=Path, default=RESULTS_ROOT / "cell_level_predictions.csv")
    args = parser.parse_args()
    missing = [p for p in [args.clean_root / "main_soh_dataset_clean.csv",
                            args.clean_root / "rul_labels_with_censoring.csv"] if not p.exists()]
    if missing:
        raise FileNotFoundError("缺少外部派生数据：" + "; ".join(str(p) for p in missing))
    base = load_base_cells(args.clean_root); candidates = load_candidates(); rows=[]
    grouped = {k:g for k,g in candidates.groupby("canonical_id")} if len(candidates) else {}
    for _, r in base.iterrows():
        item={"battery_id":r.battery_id,"dataset":r.dataset,"chemistry":r.chemistry,
              "current_cycle":r.cycle,"SOH_pred":np.nan,"SOH_lower":np.nan,"SOH_upper":np.nan,
              "RUL_pred":np.nan,"RUL_lower":np.nan,"RUL_upper":np.nan,"DCIR_mOhm":np.nan,"DCIR_growth_ratio":np.nan,
              "uncertainty_width":np.nan,"right_censored":bool(r.right_censored),"prediction_valid":False,
              "prediction_status":"not_estimable","prediction_reason":"no_model_prediction_for_cell",
              "model_name":"none","validation_stage":"unmodeled","source_runs":""}
        if r.canonical_id in grouped:
            item.update(aggregate_candidate(grouped[r.canonical_id], bool(r.right_censored)))
        rows.append(item)
    out = add_uconn_rows(pd.DataFrame(rows), args.uconn_rpt)
    order=["battery_id","dataset","chemistry","current_cycle","SOH_pred","SOH_lower","SOH_upper","RUL_pred","RUL_lower","RUL_upper",
           "DCIR_mOhm","DCIR_growth_ratio","uncertainty_width","right_censored","prediction_valid","prediction_status","prediction_reason",
           "model_name","validation_stage","source_runs"]
    out=out[order].sort_values(["dataset","battery_id"]).reset_index(drop=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    output=args.output; out.to_csv(output,index=False,encoding="utf-8-sig")
    report={"rows":len(out),"unique_batteries":int(out.battery_id.nunique()),"prediction_valid":int(out.prediction_valid.sum()),
            "status_counts":out.prediction_status.value_counts(dropna=False).to_dict(),"negative_rul_rows":int((out.RUL_pred<0).sum())}
    output.with_name("cell_level_predictions_summary.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__ == "__main__": main()
