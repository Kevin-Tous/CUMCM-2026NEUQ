"""XJTU battery dataset preprocessing and quality-control pipeline.

The raw MAT files remain read-only.  The pipeline discovers the 55 canonical
battery files, ignores Baidu Netdisk duplicate suffixes such as ``(1)``, and
exports cycle-level CSV files suitable for degradation, SOH, and RUL models.
"""

from __future__ import annotations

import argparse
import gc
import json
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.io import loadmat


LOGGER = logging.getLogger("xjtu_pipeline")
DUPLICATE_SUFFIX = re.compile(r"\(\d+\)$")
TRAILING_INTEGER = re.compile(r"-(\d+)$")
EXPECTED_BATCH_COUNTS = {
    "Batch-1": 8,
    "Batch-2": 15,
    "Batch-3": 8,
    "Batch-4": 8,
    "Batch-5": 8,
    "Batch-6": 8,
}
BATCH_METADATA = {
    "Batch-1": "fixed_2C_charge_1C_discharge_full",
    "Batch-2": "fixed_3C_charge_1C_discharge_full",
    "Batch-3": "variable_discharge_rate_full",
    "Batch-4": "variable_discharge_rate_partial",
    "Batch-5": "random_walk_partial",
    "Batch-6": "GEO_satellite_profile",
}
SUMMARY_FIELDS = (
    "charge_capacity_Ah",
    "discharge_capacity_Ah",
    "charge_power_Wh",
    "discharge_power_Wh",
    "charge_median_voltage",
    "discharge_median_voltage",
    "charge_mean_voltage",
    "discharge_mean_voltage",
)
SIGNAL_FIELDS = (
    "relative_time_min",
    "voltage_V",
    "current_A",
    "capacity_Ah",
    "power_Wh",
    "temperature_C",
)


@dataclass(frozen=True)
class PipelineConfig:
    raw_root: Path
    output_dir: Path
    pilot_file: Path
    nominal_capacity_Ah: float = 2.0


def load_config(path: Path) -> PipelineConfig:
    payload = json.loads(path.read_text(encoding="utf-8"))
    output_dir = Path(payload["output_dir"])
    if not output_dir.is_absolute():
        output_dir = path.parent / output_dir
    raw_root = Path(payload["raw_root"])
    pilot_file = raw_root / Path(payload["pilot_relative_path"])
    return PipelineConfig(
        raw_root=raw_root,
        output_dir=output_dir,
        pilot_file=pilot_file,
        nominal_capacity_Ah=float(payload.get("nominal_capacity_Ah", 2.0)),
    )


def is_duplicate_copy(path: Path) -> bool:
    """Return True for filenames ending in Baidu duplicate suffixes."""

    return DUPLICATE_SUFFIX.search(path.stem) is not None


def battery_identity(path: Path) -> tuple[str, str, int]:
    batch_id = path.parent.name
    batch_number = int(batch_id.split("-")[-1])
    match = TRAILING_INTEGER.search(path.stem)
    if not match:
        raise ValueError(f"Cannot infer cell number from {path.name}")
    cell_number = int(match.group(1))
    return f"B{batch_number}b{cell_number}", batch_id, cell_number


def discover_files(raw_root: Path) -> tuple[list[Path], pd.DataFrame]:
    if not raw_root.exists():
        raise FileNotFoundError(f"Raw dataset directory not found: {raw_root}")

    all_files: list[Path] = []
    for batch_dir in sorted(
        raw_root.glob("Batch-*"), key=lambda p: int(p.name.split("-")[-1])
    ):
        all_files.extend(sorted(batch_dir.glob("*.mat")))

    inventory_rows: list[dict[str, object]] = []
    canonical: list[Path] = []
    for path in all_files:
        duplicate = is_duplicate_copy(path)
        if not duplicate:
            canonical.append(path)
        inventory_rows.append(
            {
                "batch_id": path.parent.name,
                "file_name": path.name,
                "size_bytes": path.stat().st_size,
                "size_MB": round(path.stat().st_size / 1024**2, 3),
                "is_duplicate_copy": duplicate,
                "canonical_stem": DUPLICATE_SUFFIX.sub("", path.stem),
            }
        )

    canonical.sort(
        key=lambda p: (
            int(p.parent.name.split("-")[-1]),
            int(TRAILING_INTEGER.search(p.stem).group(1)),
        )
    )
    inventory = pd.DataFrame(inventory_rows)
    return canonical, inventory


def validate_inventory(canonical: Iterable[Path]) -> dict[str, object]:
    paths = list(canonical)
    counts = pd.Series([p.parent.name for p in paths]).value_counts().to_dict()
    mismatches = {
        batch: {"expected": expected, "found": int(counts.get(batch, 0))}
        for batch, expected in EXPECTED_BATCH_COUNTS.items()
        if int(counts.get(batch, 0)) != expected
    }
    return {
        "canonical_file_count": len(paths),
        "expected_file_count": sum(EXPECTED_BATCH_COUNTS.values()),
        "batch_counts": {k: int(counts.get(k, 0)) for k in EXPECTED_BATCH_COUNTS},
        "inventory_valid": len(paths) == 55 and not mismatches,
        "batch_mismatches": mismatches,
    }


def _as_float_vector(value: np.ndarray) -> np.ndarray:
    array = np.asarray(value).reshape(-1)
    if array.size == 0:
        return np.asarray([], dtype=float)
    return array.astype(float, copy=False)


def _as_text(value: np.ndarray) -> str:
    array = np.asarray(value).reshape(-1)
    return "" if array.size == 0 else str(array[0])


def _safe_stat(values: np.ndarray, function, default: float = np.nan) -> float:
    finite = values[np.isfinite(values)]
    return default if finite.size == 0 else float(function(finite))


def _segment_bounds(relative_time: np.ndarray) -> np.ndarray:
    if relative_time.size == 0:
        return np.asarray([0], dtype=int)
    resets = np.where(np.diff(relative_time) < -1e-9)[0] + 1
    return np.unique(np.r_[0, resets, relative_time.size]).astype(int)


def cumulative_time(relative_time: np.ndarray) -> np.ndarray:
    """Convert the per-stage reset clock to a cumulative minute axis."""

    if relative_time.size == 0:
        return relative_time.copy()
    bounds = _segment_bounds(relative_time)
    result = np.zeros(relative_time.size, dtype=float)
    offset = 0.0
    for start, end in zip(bounds[:-1], bounds[1:]):
        segment = relative_time[start:end]
        if segment.size == 0:
            continue
        base = float(segment[0]) if np.isfinite(segment[0]) else 0.0
        shifted = segment - base
        result[start:end] = shifted + offset
        duration = _safe_stat(shifted, np.nanmax, default=0.0)
        offset += max(duration, 0.0)
    return result


def _duration_by_current_state(
    relative_time: np.ndarray, current: np.ndarray, threshold_A: float = 0.02
) -> tuple[float, float, float, int]:
    bounds = _segment_bounds(relative_time)
    durations = {"charge": 0.0, "discharge": 0.0, "rest": 0.0}
    valid_segments = 0
    for start, end in zip(bounds[:-1], bounds[1:]):
        time_segment = relative_time[start:end]
        current_segment = current[start:end]
        if time_segment.size == 0:
            continue
        duration = max(
            _safe_stat(time_segment, np.nanmax, default=0.0)
            - _safe_stat(time_segment, np.nanmin, default=0.0),
            0.0,
        )
        mean_current = _safe_stat(current_segment, np.nanmean, default=0.0)
        state = (
            "charge"
            if mean_current > threshold_A
            else "discharge"
            if mean_current < -threshold_A
            else "rest"
        )
        durations[state] += duration
        valid_segments += 1
    return (
        durations["charge"],
        durations["discharge"],
        durations["rest"],
        valid_segments,
    )


def build_capacity_labels(
    raw_capacity: np.ndarray, descriptions: list[str]
) -> tuple[np.ndarray, str, np.ndarray]:
    """Return a comparable capacity trajectory and diagnostic-cycle indices.

    Partial-discharge batches contain periodic diagnostic capacity cycles.  When
    at least two are available, linear interpolation between those measurements
    avoids treating partial discharged ampere-hours as full capacity.
    """

    cycles = np.arange(1, raw_capacity.size + 1)
    test_mask = np.asarray(
        ["test capacity" in text.lower() for text in descriptions], dtype=bool
    )
    test_mask &= np.isfinite(raw_capacity)
    test_cycles = cycles[test_mask]
    if test_cycles.size >= 2:
        trajectory = np.interp(cycles, test_cycles, raw_capacity[test_mask])
        return trajectory, "diagnostic_capacity_linear_interpolation", test_cycles
    return raw_capacity.copy(), "per_cycle_discharge_capacity", test_cycles


def _summary_vector(summary: np.ndarray, field: str, cycle_count: int) -> np.ndarray:
    vector = _as_float_vector(summary[field][0, 0])
    if vector.size != cycle_count:
        raise ValueError(
            f"Summary field {field} has {vector.size} values; expected {cycle_count}"
        )
    return vector


def extract_cycle_features(data: np.ndarray, cycle_index: int) -> dict[str, object]:
    signals = {
        field: _as_float_vector(data[field][0, cycle_index]) for field in SIGNAL_FIELDS
    }
    description = _as_text(data["description"][0, cycle_index])
    time = signals["relative_time_min"]
    voltage = signals["voltage_V"]
    current = signals["current_A"]
    temperature = signals["temperature_C"]
    common_length = min(time.size, voltage.size, current.size, temperature.size)
    if common_length == 0:
        raise ValueError(f"Cycle {cycle_index + 1} has empty core signals")
    time = time[:common_length]
    voltage = voltage[:common_length]
    current = current[:common_length]
    temperature = temperature[:common_length]
    charge_duration, discharge_duration, rest_duration, stage_count = (
        _duration_by_current_state(time, current)
    )
    positive = current[current > 0.02]
    negative = current[current < -0.02]
    cumulative = cumulative_time(time)
    return {
        "sample_count": int(common_length),
        "stage_count": int(stage_count),
        "cycle_duration_min": _safe_stat(cumulative, np.nanmax, default=0.0),
        "charge_duration_min": charge_duration,
        "discharge_duration_min": discharge_duration,
        "rest_duration_min": rest_duration,
        "mean_abs_current_A": _safe_stat(np.abs(current), np.nanmean),
        "rms_current_A": _safe_stat(current**2, lambda x: np.sqrt(np.nanmean(x))),
        "mean_charge_current_A": _safe_stat(positive, np.nanmean),
        "peak_charge_current_A": _safe_stat(positive, np.nanmax),
        "mean_discharge_current_A": abs(_safe_stat(negative, np.nanmean)),
        "peak_discharge_current_A": abs(_safe_stat(negative, np.nanmin)),
        "min_voltage_V": _safe_stat(voltage, np.nanmin),
        "max_voltage_V": _safe_stat(voltage, np.nanmax),
        "mean_voltage_V": _safe_stat(voltage, np.nanmean),
        "mean_temperature_C": _safe_stat(temperature, np.nanmean),
        "max_temperature_C": _safe_stat(temperature, np.nanmax),
        "temperature_rise_C": _safe_stat(temperature, np.nanmax)
        - _safe_stat(temperature, np.nanmin),
        "description": description,
    }


def _pilot_curve_rows(
    data: np.ndarray, battery_id: str, cycle_indices: Iterable[int]
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for cycle_index in cycle_indices:
        time = _as_float_vector(data["relative_time_min"][0, cycle_index])
        cumulative = cumulative_time(time)
        voltage = _as_float_vector(data["voltage_V"][0, cycle_index])
        current = _as_float_vector(data["current_A"][0, cycle_index])
        temperature = _as_float_vector(data["temperature_C"][0, cycle_index])
        length = min(cumulative.size, voltage.size, current.size, temperature.size)
        for index in range(length):
            rows.append(
                {
                    "battery_id": battery_id,
                    "cycle": cycle_index + 1,
                    "sample": index,
                    "cumulative_time_min": cumulative[index],
                    "voltage_V": voltage[index],
                    "current_A": current[index],
                    "temperature_C": temperature[index],
                }
            )
    return rows


def process_battery(
    path: Path, include_pilot_curves: bool = False
) -> tuple[pd.DataFrame, dict[str, object], pd.DataFrame | None]:
    battery_id, batch_id, cell_number = battery_identity(path)
    LOGGER.info("Loading %s (%s)", battery_id, path.name)
    mat = loadmat(path, variable_names=["data", "summary"])
    data = mat["data"]
    summary = mat["summary"]
    cycle_count = int(np.asarray(summary["cycle_life"][0, 0]).reshape(-1)[0])
    if data.shape[1] != cycle_count:
        raise ValueError(
            f"{battery_id}: data cycles={data.shape[1]}, cycle_life={cycle_count}"
        )

    summary_vectors = {
        field: _summary_vector(summary, field, cycle_count) for field in SUMMARY_FIELDS
    }
    descriptions = [
        _as_text(data["description"][0, index]) for index in range(cycle_count)
    ]
    raw_capacity = summary_vectors["discharge_capacity_Ah"]
    capacity, label_method, diagnostic_cycles = build_capacity_labels(
        raw_capacity, descriptions
    )
    finite_capacity = capacity[np.isfinite(capacity)]
    if finite_capacity.size == 0:
        raise ValueError(f"{battery_id}: no finite capacity values")
    initial_capacity = float(finite_capacity[0])

    rows: list[dict[str, object]] = []
    for cycle_index in range(cycle_count):
        cycle_features = extract_cycle_features(data, cycle_index)
        row: dict[str, object] = {
            "battery_id": battery_id,
            "batch_id": batch_id,
            "cell_number": cell_number,
            "strategy": BATCH_METADATA[batch_id],
            "source_file": path.name,
            "cycle": cycle_index + 1,
            "cycle_life": cycle_count,
            "RUL_cycles": cycle_count - (cycle_index + 1),
            "raw_discharge_capacity_Ah": raw_capacity[cycle_index],
            "capacity_label_Ah": capacity[cycle_index],
            "SOH": capacity[cycle_index] / initial_capacity,
            "capacity_label_method": label_method,
            "is_diagnostic_capacity_cycle": bool(
                cycle_index + 1 in set(diagnostic_cycles.tolist())
            ),
        }
        for field, vector in summary_vectors.items():
            row[field] = vector[cycle_index]
        row.update(cycle_features)
        rows.append(row)

    cycle_frame = pd.DataFrame(rows)
    battery_row: dict[str, object] = {
        "battery_id": battery_id,
        "batch_id": batch_id,
        "cell_number": cell_number,
        "strategy": BATCH_METADATA[batch_id],
        "source_file": path.name,
        "source_size_MB": round(path.stat().st_size / 1024**2, 3),
        "cycle_life": cycle_count,
        "diagnostic_capacity_cycle_count": int(diagnostic_cycles.size),
        "capacity_label_method": label_method,
        "initial_capacity_Ah": initial_capacity,
        "final_capacity_Ah": float(capacity[-1]),
        "final_SOH": float(capacity[-1] / initial_capacity),
        "minimum_SOH": float(np.nanmin(capacity / initial_capacity)),
        "maximum_temperature_C": float(cycle_frame["max_temperature_C"].max()),
        "maximum_discharge_current_A": float(
            cycle_frame["peak_discharge_current_A"].max()
        ),
        "mat_description": _as_text(summary["description"][0, 0]),
    }

    curves: pd.DataFrame | None = None
    if include_pilot_curves:
        selected = sorted({0, cycle_count // 2, cycle_count - 1})
        curves = pd.DataFrame(_pilot_curve_rows(data, battery_id, selected))

    del mat, data, summary
    gc.collect()
    return cycle_frame, battery_row, curves


def plot_pilot(
    cycle_frame: pd.DataFrame,
    curves: pd.DataFrame,
    figure_dir: Path,
) -> None:
    figure_dir.mkdir(parents=True, exist_ok=True)
    battery_id = str(cycle_frame["battery_id"].iloc[0])

    fig, axis_left = plt.subplots(figsize=(9, 5.5))
    axis_left.plot(
        cycle_frame["cycle"],
        cycle_frame["raw_discharge_capacity_Ah"],
        color="#8aa9c4",
        linewidth=1,
        alpha=0.75,
        label="Raw discharge capacity",
    )
    axis_left.plot(
        cycle_frame["cycle"],
        cycle_frame["capacity_label_Ah"],
        color="#176b87",
        linewidth=2,
        label="Capacity label",
    )
    axis_left.set_xlabel("Cycle")
    axis_left.set_ylabel("Capacity (Ah)")
    axis_left.grid(alpha=0.25)
    axis_right = axis_left.twinx()
    axis_right.plot(
        cycle_frame["cycle"],
        cycle_frame["SOH"],
        color="#c94c4c",
        linewidth=1.5,
        label="SOH",
    )
    axis_right.axhline(0.8, color="#c94c4c", linestyle="--", alpha=0.65)
    axis_right.set_ylabel("SOH")
    handles_left, labels_left = axis_left.get_legend_handles_labels()
    handles_right, labels_right = axis_right.get_legend_handles_labels()
    axis_left.legend(handles_left + handles_right, labels_left + labels_right)
    axis_left.set_title(f"{battery_id}: capacity degradation quality check")
    fig.tight_layout()
    fig.savefig(figure_dir / f"{battery_id}_capacity_qc.png", dpi=180)
    plt.close(fig)

    fig, axes = plt.subplots(3, 1, figsize=(10, 8), sharex=True)
    for cycle, group in curves.groupby("cycle"):
        label = f"Cycle {cycle}"
        axes[0].plot(group["cumulative_time_min"], group["voltage_V"], label=label)
        axes[1].plot(group["cumulative_time_min"], group["current_A"], label=label)
        axes[2].plot(
            group["cumulative_time_min"], group["temperature_C"], label=label
        )
    axes[0].set_ylabel("Voltage (V)")
    axes[1].set_ylabel("Current (A)")
    axes[2].set_ylabel("Temperature (C)")
    axes[2].set_xlabel("Cumulative cycle time (min)")
    for axis in axes:
        axis.grid(alpha=0.25)
        axis.legend(ncol=3, fontsize=8)
    fig.suptitle(f"{battery_id}: representative cycle curves")
    fig.tight_layout()
    fig.savefig(figure_dir / f"{battery_id}_representative_curves.png", dpi=180)
    plt.close(fig)


def plot_fleet(
    cycle_frame: pd.DataFrame, battery_frame: pd.DataFrame, figure_dir: Path
) -> None:
    figure_dir.mkdir(parents=True, exist_ok=True)
    fig, axis = plt.subplots(figsize=(10, 6))
    for (batch_id, battery_id), group in cycle_frame.groupby(
        ["batch_id", "battery_id"], sort=False
    ):
        axis.plot(group["cycle"], group["SOH"], linewidth=0.8, alpha=0.55)
    axis.axhline(0.8, color="black", linestyle="--", linewidth=1, label="80% EOL")
    axis.set_xlabel("Cycle")
    axis.set_ylabel("SOH")
    axis.set_title("XJTU fleet capacity trajectories")
    axis.grid(alpha=0.2)
    axis.legend()
    fig.tight_layout()
    fig.savefig(figure_dir / "fleet_SOH_trajectories.png", dpi=180)
    plt.close(fig)

    ordered = [f"Batch-{index}" for index in range(1, 7)]
    grouped = [
        battery_frame.loc[battery_frame["batch_id"] == batch, "cycle_life"].to_numpy()
        for batch in ordered
    ]
    fig, axis = plt.subplots(figsize=(9, 5.5))
    axis.boxplot(grouped, tick_labels=ordered, showmeans=True)
    axis.set_ylabel("Cycle life")
    axis.set_title("Cycle-life distribution by batch")
    axis.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(figure_dir / "cycle_life_by_batch.png", dpi=180)
    plt.close(fig)


def make_quality_report(
    inventory: pd.DataFrame,
    inventory_report: dict[str, object],
    cycles: pd.DataFrame | None = None,
    batteries: pd.DataFrame | None = None,
    errors: list[dict[str, str]] | None = None,
) -> dict[str, object]:
    report = dict(inventory_report)
    report.update(
        {
            "all_mat_file_count": int(len(inventory)),
            "duplicate_copy_count": int(inventory["is_duplicate_copy"].sum()),
            "duplicate_copy_size_GB": round(
                inventory.loc[inventory["is_duplicate_copy"], "size_bytes"].sum()
                / 1024**3,
                3,
            ),
        }
    )
    if cycles is not None and batteries is not None:
        report.update(
            {
                "processed_battery_count": int(len(batteries)),
                "processed_cycle_count": int(len(cycles)),
                "duplicate_battery_cycle_rows": int(
                    cycles.duplicated(["battery_id", "cycle"]).sum()
                ),
                "nonfinite_SOH_rows": int((~np.isfinite(cycles["SOH"])).sum()),
                "SOH_below_0_5_rows": int((cycles["SOH"] < 0.5).sum()),
                "SOH_above_1_2_rows": int((cycles["SOH"] > 1.2).sum()),
                "final_SOH_range": [
                    float(batteries["final_SOH"].min()),
                    float(batteries["final_SOH"].max()),
                ],
            }
        )
    report["processing_errors"] = errors or []
    report["processing_valid"] = bool(
        report.get("inventory_valid", False)
        and not report["processing_errors"]
        and report.get("duplicate_battery_cycle_rows", 0) == 0
        and report.get("nonfinite_SOH_rows", 0) == 0
    )
    return report


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def atomic_to_csv(frame: pd.DataFrame, path: Path) -> None:
    """Write a CSV checkpoint without leaving a half-written target file."""

    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temporary, index=False, encoding="utf-8-sig")
    temporary.replace(path)


def run_inventory(config: PipelineConfig) -> None:
    config.output_dir.mkdir(parents=True, exist_ok=True)
    canonical, inventory = discover_files(config.raw_root)
    report = validate_inventory(canonical)
    inventory.to_csv(config.output_dir / "inventory.csv", index=False, encoding="utf-8-sig")
    quality = make_quality_report(inventory, report)
    write_json(config.output_dir / "inventory_report.json", quality)
    LOGGER.info("Found %d canonical battery files", len(canonical))
    if not report["inventory_valid"]:
        raise RuntimeError(f"Dataset inventory mismatch: {report}")


def run_pilot(config: PipelineConfig) -> None:
    config.output_dir.mkdir(parents=True, exist_ok=True)
    figure_dir = config.output_dir / "figures"
    canonical, inventory = discover_files(config.raw_root)
    inventory_report = validate_inventory(canonical)
    if not inventory_report["inventory_valid"]:
        raise RuntimeError(f"Dataset inventory mismatch: {inventory_report}")
    cycle_frame, battery_row, curves = process_battery(
        config.pilot_file, include_pilot_curves=True
    )
    assert curves is not None
    cycle_frame.to_csv(
        config.output_dir / "pilot_cycle_summary.csv", index=False, encoding="utf-8-sig"
    )
    curves.to_csv(
        config.output_dir / "pilot_representative_curves.csv",
        index=False,
        encoding="utf-8-sig",
    )
    pd.DataFrame([battery_row]).to_csv(
        config.output_dir / "pilot_battery_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )
    plot_pilot(cycle_frame, curves, figure_dir)
    quality = make_quality_report(
        inventory,
        inventory_report,
        cycle_frame,
        pd.DataFrame([battery_row]),
    )
    write_json(config.output_dir / "pilot_quality_report.json", quality)


def run_all(config: PipelineConfig) -> None:
    config.output_dir.mkdir(parents=True, exist_ok=True)
    figure_dir = config.output_dir / "figures"
    checkpoint_dir = config.output_dir / "checkpoints"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    canonical, inventory = discover_files(config.raw_root)
    inventory_report = validate_inventory(canonical)
    if not inventory_report["inventory_valid"]:
        raise RuntimeError(f"Dataset inventory mismatch: {inventory_report}")
    inventory.to_csv(config.output_dir / "inventory.csv", index=False, encoding="utf-8-sig")

    all_cycles: list[pd.DataFrame] = []
    battery_rows: list[dict[str, object]] = []
    errors: list[dict[str, str]] = []
    for index, path in enumerate(canonical, start=1):
        battery_id, _, _ = battery_identity(path)
        cycle_checkpoint = checkpoint_dir / f"{battery_id}_cycles.csv"
        battery_checkpoint = checkpoint_dir / f"{battery_id}_battery.csv"
        try:
            if cycle_checkpoint.exists() and battery_checkpoint.exists():
                cycle_frame = pd.read_csv(cycle_checkpoint)
                battery_frame = pd.read_csv(battery_checkpoint)
                if cycle_frame.empty or len(battery_frame) != 1:
                    raise ValueError("Incomplete checkpoint")
                battery_row = battery_frame.iloc[0].to_dict()
                LOGGER.info("Resumed %d/%d: %s", index, len(canonical), path.name)
            else:
                cycle_frame, battery_row, _ = process_battery(path)
                atomic_to_csv(cycle_frame, cycle_checkpoint)
                atomic_to_csv(pd.DataFrame([battery_row]), battery_checkpoint)
                LOGGER.info("Processed %d/%d: %s", index, len(canonical), path.name)
            all_cycles.append(cycle_frame)
            battery_rows.append(battery_row)
            write_json(
                config.output_dir / "progress.json",
                {
                    "status": "running",
                    "completed_batteries": index,
                    "total_batteries": len(canonical),
                    "latest_battery": battery_id,
                },
            )
        except Exception as exc:  # Continue to create an explicit error report.
            LOGGER.exception("Failed to process %s", path)
            errors.append({"file": str(path), "error": repr(exc)})

    if not all_cycles:
        raise RuntimeError("No battery files were processed successfully")
    cycles = pd.concat(all_cycles, ignore_index=True)
    batteries = pd.DataFrame(battery_rows).sort_values(["batch_id", "cell_number"])
    cycles = cycles.sort_values(["batch_id", "cell_number", "cycle"])
    cycles.to_csv(
        config.output_dir / "xjtu_cycle_summary.csv", index=False, encoding="utf-8-sig"
    )
    batteries.to_csv(
        config.output_dir / "xjtu_battery_summary.csv", index=False, encoding="utf-8-sig"
    )
    if errors:
        pd.DataFrame(errors).to_csv(
            config.output_dir / "processing_errors.csv", index=False, encoding="utf-8-sig"
        )
    plot_fleet(cycles, batteries, figure_dir)
    quality = make_quality_report(
        inventory, inventory_report, cycles, batteries, errors
    )
    write_json(config.output_dir / "quality_report.json", quality)
    write_json(
        config.output_dir / "progress.json",
        {
            "status": "complete" if not errors else "complete_with_errors",
            "completed_batteries": len(batteries),
            "total_batteries": len(canonical),
            "error_count": len(errors),
        },
    )
    if errors:
        raise RuntimeError(f"{len(errors)} battery files failed; see processing_errors.csv")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "mode", choices=("inventory", "pilot", "all"), help="Pipeline stage to run"
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path(__file__).with_name("config.json"),
        help="Path to pipeline JSON configuration",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%H:%M:%S",
    )
    config = load_config(args.config.resolve())
    if args.mode == "inventory":
        run_inventory(config)
    elif args.mode == "pilot":
        run_pilot(config)
    else:
        run_all(config)


if __name__ == "__main__":
    main()
