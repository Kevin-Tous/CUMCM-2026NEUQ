"""Audit raw-observation 80% EOL first passage and dataset summaries.

EOL is an absorbing event at the first valid SOH <= 0.80.  The raw valid
trajectory is not forced to be monotonic; later rebound is reported through
``threshold_recrossed`` but does not undo an already observed EOL event.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "results/degradation/data"
TABLES = ROOT / "results/degradation/tables"


def main() -> None:
    curves = pd.read_csv(DATA / "unified_capacity_curves.csv", low_memory=False)
    rows = []
    for (dataset, battery_id), group in curves.groupby(["dataset", "battery_id"], sort=True):
        valid = group.dropna(subset=["SOH"]).sort_values("cycle")
        crossed = valid[valid["SOH"] <= 0.80]
        rows.append({
            "dataset": dataset,
            "battery_id": battery_id,
            "valid_observations": int(len(valid)),
            "reached_eol_80pct": bool(len(crossed)),
            "first_eol_cycle": int(crossed.iloc[0]["cycle"]) if len(crossed) else np.nan,
            "right_censored_at_80pct": bool(len(valid) and not len(crossed)),
            "final_soh": float(valid.iloc[-1]["SOH"]) if len(valid) else np.nan,
            "threshold_recrossed": bool(len(crossed) and valid.iloc[-1]["SOH"] > 0.80),
        })
    audit = pd.DataFrame(rows)
    audit.to_csv(TABLES / "right_censoring_80pct_cell_audit.csv", index=False, encoding="utf-8-sig")

    manifest_path = DATA / "feature_dataset_manifest.csv"
    manifest = pd.read_csv(manifest_path)
    old = [
        c for c in manifest.columns
        if c in {"right_censored_at_85pct", "reached_eol_80pct", "right_censored_at_80pct"}
    ]
    manifest = manifest.drop(columns=old)
    manifest = manifest.merge(
        audit[["battery_id", "reached_eol_80pct", "right_censored_at_80pct"]],
        on="battery_id", how="left",
    )
    manifest["reached_eol_80pct"] = manifest["reached_eol_80pct"].fillna(False).astype(bool)
    manifest["right_censored_at_80pct"] = manifest["right_censored_at_80pct"].fillna(False).astype(bool)
    manifest.to_csv(manifest_path, index=False, encoding="utf-8-sig")

    summary = (
        manifest.groupby("dataset", as_index=False)
        .agg(
            csv_files=("relative_file", "count"), independent_cells=("independent_cell", "sum"),
            cycles=("n_cycles", "sum"), missing_values=("n_missing", "sum"),
            infinite_values=("n_infinite", "sum"), median_final_SOH=("final_soh", "median"),
            censored_cells=("right_censored_at_80pct", "sum"),
        )
        .sort_values("dataset")
    )
    summary.to_csv(TABLES / "dataset_summary.csv", index=False, encoding="utf-8-sig")
    print(audit.groupby("dataset")["right_censored_at_80pct"].sum().to_string())
    print(f"total={int(audit.right_censored_at_80pct.sum())}; recrossed={int(audit.threshold_recrossed.sum())}")


if __name__ == "__main__":
    main()
