"""Generate auditable evidence that closes the remaining A-question gaps.

The script deliberately reuses only formal leave-battery XGBoost predictions,
the published semi-empirical stress model, and the cell-level prediction interface. It
does not mix simulated rows into model training.
"""
from __future__ import annotations

import argparse
import hashlib
import sys
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Noto Sans CJK SC", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code" / "soh_rul"))
from rul import rul_from_samples  # noqa: E402


def formal_member_predictions(package: Path) -> pd.DataFrame:
    frames = []
    if package.is_dir():
        sources = sorted(
            path for path in package.rglob("soh_member_predictions.csv")
            if "xgboost_leave_battery_fold" in path.as_posix()
        )
        if len(sources) != 5:
            raise ValueError(f"Expected five formal leave-battery folds, got {len(sources)}")
        for source in sources:
            frame = pd.read_csv(source)
            name = source.as_posix()
            frame["fold"] = int(name.split("xgboost_leave_battery_fold", 1)[1].split("/", 1)[0])
            frames.append(frame)
    else:
        with zipfile.ZipFile(package) as archive:
            names = [
                name for name in archive.namelist()
                if name.endswith("soh_member_predictions.csv")
                and "xgboost_leave_battery_fold" in name
            ]
            if len(names) != 5:
                raise ValueError(f"Expected five formal leave-battery folds, got {len(names)}")
            for name in sorted(names):
                with archive.open(name) as stream:
                    frame = pd.read_csv(stream)
                frame["fold"] = int(name.split("xgboost_leave_battery_fold", 1)[1].split("/", 1)[0])
                frames.append(frame)
    result = pd.concat(frames, ignore_index=True)
    if result["battery_id"].nunique() != 55:
        raise ValueError("Formal folds do not cover exactly 55 XJTU cells")
    return result


def forward_rul_backtest(pred: pd.DataFrame, out: Path, fraction: float = 0.85) -> pd.DataFrame:
    members = [c for c in pred.columns if c.startswith("SOH_member_")]
    rows = []
    for battery_id, group in pred.groupby("battery_id", sort=True):
        group = group.sort_values("cycle")
        crossed = group.loc[group["SOH"] <= 0.80, "cycle"]
        if crossed.empty:
            continue
        true_eol = int(crossed.iloc[0])
        cut_cycle = int(np.floor(fraction * true_eol))
        history = group[group["cycle"] <= cut_cycle]
        if len(history) < 20:
            continue
        info = rul_from_samples(
            history["cycle"].to_numpy(), history[members].to_numpy().T,
            current_cycle=cut_cycle, threshold=0.80,
            max_extrapolation_cycles=2000, max_extrapolation_factor=3.0,
            max_interval_width_cycles=2000, min_valid_sample_fraction=0.5,
        )
        row = {
            "battery_id": battery_id,
            "condition_id": group["condition_id"].iloc[0],
            "true_eol_cycle": true_eol,
            "cut_fraction": fraction,
            "cut_cycle": cut_cycle,
            "true_rul": true_eol - cut_cycle,
            **info,
        }
        rows.append(row)
    detail = pd.DataFrame(rows)
    valid = detail[detail["rul_valid"]].copy()
    valid["error"] = valid["rul_median"] - valid["true_rul"]
    valid["abs_error"] = valid["error"].abs()
    valid["ape_pct"] = 100 * valid["abs_error"] / valid["true_rul"].clip(lower=1)
    valid["member_interval_hit"] = (
        (valid["true_rul"] >= valid["rul_lower"])
        & (valid["true_rul"] <= valid["rul_upper"])
    )

    # Leave-one-cell-out residual expansion.  This is diagnostic calibration,
    # not used to alter the downstream screening decisions.
    calibrated_lower, calibrated_upper = [], []
    residuals = valid["abs_error"].to_numpy()
    for pos, (_, row) in enumerate(valid.iterrows()):
        calibration = np.delete(residuals, pos)
        rank = min(len(calibration), int(np.ceil((len(calibration) + 1) * 0.90))) - 1
        q90 = float(np.sort(calibration)[rank])
        calibrated_lower.append(max(0.0, float(row["rul_median"]) - q90))
        calibrated_upper.append(float(row["rul_median"]) + q90)
    valid["calibrated_lower_90"] = calibrated_lower
    valid["calibrated_upper_90"] = calibrated_upper
    valid["calibrated_hit_90"] = (
        (valid["true_rul"] >= valid["calibrated_lower_90"])
        & (valid["true_rul"] <= valid["calibrated_upper_90"])
    )
    valid.to_csv(out / "rul_forward_backtest_detail.csv", index=False, encoding="utf-8-sig")
    summary = pd.DataFrame([{
        "observed_eol_cells": int(len(detail)),
        "valid_backtests": int(len(valid)),
        "cut_fraction": fraction,
        "RUL_MAE": float(valid["abs_error"].mean()),
        "RUL_RMSE": float(np.sqrt(np.mean(valid["error"] ** 2))),
        "RUL_MAPE_pct": float(valid["ape_pct"].mean()),
        "RUL_MedianAE": float(valid["abs_error"].median()),
        "RUL_bias": float(valid["error"].mean()),
        "member_PICP": float(valid["member_interval_hit"].mean()),
        "member_MPIW": float((valid["rul_upper"] - valid["rul_lower"]).mean()),
        "LOOCV_residual_PICP_90": float(valid["calibrated_hit_90"].mean()),
        "LOOCV_residual_MPIW_90": float(
            (valid["calibrated_upper_90"] - valid["calibrated_lower_90"]).mean()
        ),
    }])
    summary.to_csv(out / "rul_forward_backtest_summary.csv", index=False, encoding="utf-8-sig")
    return summary


def stress_coupling(out: Path) -> pd.DataFrame:
    scenarios = pd.read_csv(ROOT / "results" / "degradation" / "data" /
                            "simulated_capacity_resistance_scenarios.csv")
    eol_rows = []
    for scenario, group in scenarios.groupby("scenario", sort=False):
        hit = group[group["SOH_simulated"] <= 0.80]
        eol = float(hit["cycle"].iloc[0]) if len(hit) else np.nan
        eol_rows.append({"stress_scenario": scenario, "stress_eol": eol})
    eol = pd.DataFrame(eol_rows)
    baseline = float(eol.loc[eol.stress_scenario == "baseline", "stress_eol"].iloc[0])
    eol["life_factor"] = eol["stress_eol"] / baseline

    official = pd.read_csv(ROOT / "results" / "prediction" / "tables" / "battery_prediction_interface.csv")
    official = official[official["prediction_valid"]].copy()
    map_names = {
        "cold_0C": "极端低温 $0^\\circ$C",
        "hot_45C": "长期高温 $45^\\circ$C",
        "deep_DOD100": "过放代理（100\\% DOD）",
        "fast_3C": "大倍率 3C",
        "aggressive_charge": "过充/激进充电代理",
    }
    rows = []
    for _, stress in eol.iterrows():
        if stress["stress_scenario"] not in map_names or not np.isfinite(stress["life_factor"]):
            continue
        factor = float(stress["life_factor"])
        for _, cell in official.iterrows():
            rows.append({
                "scenario": stress["stress_scenario"],
                "scenario_label": map_names[stress["stress_scenario"]],
                "battery_id": cell["battery_id"],
                "baseline_rul": cell["RUL_pred"],
                "corrected_rul": max(0.0, float(cell["RUL_pred"]) * factor),
                "life_factor": factor,
            })
    detail = pd.DataFrame(rows)
    detail.to_csv(out / "xgboost_stress_coupling_detail.csv", index=False, encoding="utf-8-sig")
    summary = detail.groupby(["scenario", "scenario_label", "life_factor"], as_index=False).agg(
        cells=("battery_id", "nunique"),
        median_baseline_rul=("baseline_rul", "median"),
        median_corrected_rul=("corrected_rul", "median"),
    )
    summary["median_rul_change_pct"] = 100 * (
        summary["median_corrected_rul"] / summary["median_baseline_rul"] - 1
    )
    summary.to_csv(out / "xgboost_stress_coupling_summary.csv", index=False, encoding="utf-8-sig")
    return summary


def stable_uniform(identifier: str, scenario: str, seed: int) -> float:
    raw = hashlib.sha256(f"{seed}|{scenario}|{identifier}".encode()).digest()[:8]
    return int.from_bytes(raw, "big") / float(2**64 - 1)


def repeated_scenario_robustness(out: Path) -> pd.DataFrame:
    cells = pd.read_csv(ROOT / "results" / "prediction" / "tables" / "battery_prediction_interface.csv")
    valid = cells[cells["prediction_valid"]].copy()
    rate_map = {"2C": .55, "3C": 1., "R2.5": .78, "R3": .92, "RW": .58, "Sim_satellite": .38}
    rate = valid["condition_id"].map(rate_map).fillna(.65).to_numpy()
    soh_v = ((.91 - valid["SOH_pred"]) - (.91 - valid["SOH_pred"]).min())
    soh_v = (soh_v / max(float(soh_v.max()), 1e-9)).to_numpy()
    unc = valid["uncertainty_width"]
    unc_v = ((unc - unc.min()) / max(float(unc.max() - unc.min()), 1e-9)).to_numpy()
    vulnerability = .65 * soh_v + .35 * unc_v
    rows = []
    rules = {
        "A": (.86, 40., 180.), "B": (.83, 15., 180.), "C": (.80, 8., 220.)
    }
    for scenario in ("high_temperature", "frequent_high_rate", "batch_dispersion"):
        for seed in range(2026, 2226):
            accepted, grades = 0, {"A": 0, "B": 0, "C": 0}
            for pos, (_, cell) in enumerate(valid.iterrows()):
                u = stable_uniform(str(cell["battery_id"]), scenario, seed)
                v, rt = float(vulnerability[pos]), float(rate[pos])
                if scenario == "high_temperature":
                    dh = .006 + .010*v + .003*rt + .003*u
                    rf = np.clip(.84 - .13*v - .06*rt - .03*u, .55, .84)
                    uf = 1.12 + .18*v + .08*u
                elif scenario == "frequent_high_rate":
                    dh = .004 + .007*v + .008*rt + .002*u
                    rf = np.clip(.91 - .20*rt - .06*v - .03*u, .52, .86)
                    uf = 1.10 + .24*rt + .06*u
                else:
                    signed = 2*u - 1
                    bs = {"2C":.8,"3C":1.,"R2.5":1.15,"R3":1.1,"RW":.65,"Sim_satellite":.75}.get(str(cell["condition_id"]),1.)
                    dh = .003 + .014*bs*max(0.,-signed) + .003*v
                    rf = np.clip(.92 + .12*signed - .08*bs - .05*v, .62, .98)
                    uf = 1.22 + .28*abs(signed)*bs + .08*v
                h, l, w = float(cell["SOH_pred"])-dh, float(cell["RUL_lower"])*rf, float(cell["uncertainty_width"])*uf
                grade = next((g for g,t in rules.items() if h>=t[0] and l>=t[1] and w<=t[2]), None)
                if grade:
                    accepted += 1; grades[grade] += 1
            rows.append({"scenario":scenario,"seed":seed,"accepted_count":accepted,**{f"{g}_count":n for g,n in grades.items()}})
    detail = pd.DataFrame(rows)
    detail.to_csv(out / "scenario_repeated_robustness_detail.csv", index=False, encoding="utf-8-sig")
    summary = detail.groupby("scenario", as_index=False).agg(
        runs=("seed", "count"), mean_accepted=("accepted_count", "mean"),
        std_accepted=("accepted_count", "std"), q05_accepted=("accepted_count", lambda x:x.quantile(.05)),
        q95_accepted=("accepted_count", lambda x:x.quantile(.95)), min_accepted=("accepted_count", "min"),
        max_accepted=("accepted_count", "max"),
    )
    summary.to_csv(out / "scenario_repeated_robustness_summary.csv", index=False, encoding="utf-8-sig")
    return summary


def make_figure(out: Path) -> None:
    backtest = pd.read_csv(out / "rul_forward_backtest_detail.csv")
    stress = pd.read_csv(out / "xgboost_stress_coupling_summary.csv")
    fig, axes = plt.subplots(1, 2, figsize=(10.4, 4.2))
    ax = axes[0]
    ax.scatter(backtest["true_rul"], backtest["rul_median"], s=34, color="#2878B5", alpha=.86)
    lim = max(float(backtest["true_rul"].max()), float(backtest["rul_median"].max())) * 1.05
    ax.plot([0, lim], [0, lim], "--", color="#555555", lw=1)
    ax.set(xlabel="85% EOL截断时的真实RUL/循环", ylabel="预测RUL/循环",
           title="RUL前向截断回测")
    ax.grid(alpha=.22)
    ax = axes[1]
    stress = stress.sort_values("median_rul_change_pct")
    labels = ["激进充电代理", "3C大倍率", "高温45℃", "深放电100% DOD", "低温0℃"]
    ax.barh(labels, stress["median_rul_change_pct"], color="#D9534F")
    ax.axvline(0, color="#444444", lw=.8)
    ax.set(xlabel="RUL中位数变化/%", title="应力修正后的XGBoost RUL")
    ax.grid(axis="x", alpha=.22)
    fig.tight_layout()
    fig.savefig(out / "rul_backtest_and_stress_coupling.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    default_models = ROOT / "results" / "prediction" / "folds"
    legacy_packages = list(ROOT.glob("* (3).zip"))
    default_package = default_models if default_models.exists() else (
        legacy_packages[0] if legacy_packages else None
    )
    parser.add_argument(
        "--package", type=Path, default=default_package,
        help="正式五折预测结果目录，或包含这些结果的 ZIP 包。",
    )
    parser.add_argument("--output", type=Path, default=ROOT / "paper" / "assets" / "gap_closure")
    args = parser.parse_args()
    if args.package is None:
        parser.error("未找到正式五折预测结果；请通过 --package 指定结果目录或 ZIP 包。")
    args.output.mkdir(parents=True, exist_ok=True)
    pred = formal_member_predictions(args.package)
    print(forward_rul_backtest(pred, args.output).to_string(index=False))
    print(stress_coupling(args.output).to_string(index=False))
    print(repeated_scenario_robustness(args.output).to_string(index=False))
    make_figure(args.output)


if __name__ == "__main__":
    main()
