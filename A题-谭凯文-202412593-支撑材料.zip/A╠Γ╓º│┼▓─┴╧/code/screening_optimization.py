"""退役电池安全筛选、多目标编组、经济评价与场景仿真。

运行示例：
python code/screening_optimization.py --input results/prediction/tables/battery_prediction_interface.csv --output results/screening/baseline

方法边界：预测接口不含实测温度、内阻、绝缘与热失控数据，因此本文给出的
A/B/C 是“梯次利用优先级建议”，不能替代法规要求的复检和安全认证。
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


RANDOM_SEED = 2026
GRADE_ORDER = ["A", "B", "C"]


@dataclass(frozen=True)
class GradeRule:
    min_soh: float
    min_rul_lower: float
    max_uncertainty: float
    annual_benefit: float
    annual_om_cost: float
    annual_loss_cost: float
    service_years: int
    risk_reserve_rate: float
    application: str


RULES: Dict[str, GradeRule] = {
    "A": GradeRule(0.86, 40.0, 180.0, 72.0, 5.5, 4.5, 5, 0.14, "电网侧调节/高可靠储能"),
    "B": GradeRule(0.83, 15.0, 180.0, 58.0, 4.5, 3.5, 3, 0.18, "通信基站/常规固定式储能"),
    "C": GradeRule(0.80, 8.0, 220.0, 42.0, 4.0, 3.0, 2, 0.24, "低功率固定式储能（复检后）"),
}

ECON = {
    "inspection_cost": 12.5,
    "regroup_cost": 18.0,
    "salvage_value": 15.0,
    "discount_rate": 0.05,
}

BASE_WEIGHTS = {
    "soh_consistency": 0.35,
    "rul_consistency": 0.25,
    "uncertainty_consistency": 0.15,
    "usable_life_loss": 0.25,
}

RATE_STRESS = {
    "2C": 0.55,
    "3C": 1.00,
    "R2.5": 0.78,
    "R3": 0.92,
    "RW": 0.58,
    "Sim_satellite": 0.38,
}


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="梯次利用筛选与组配优化")
    p.add_argument("--input", required=True, type=Path, help="电芯级 SOH/RUL 预测接口表")
    p.add_argument("--output", required=True, type=Path, help="结果输出目录")
    p.add_argument("--seed", type=int, default=RANDOM_SEED)
    p.add_argument("--iterations", type=int, default=80, help="每个初解的最大确定性交换轮数")
    p.add_argument(
        "--rul-bound-type", choices=["empirical", "residual-stress"], default="empirical",
        help="写入元数据的RUL边界口径；residual-stress仅用于残差扩展压力测试。",
    )
    return p.parse_args()


def configure_chinese_font() -> str:
    candidates = ["Microsoft YaHei", "SimHei", "Noto Sans CJK SC", "Arial Unicode MS"]
    installed = {f.name for f in __import__("matplotlib").font_manager.fontManager.ttflist}
    selected = next((x for x in candidates if x in installed), "DejaVu Sans")
    plt.rcParams["font.sans-serif"] = [selected, "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["figure.dpi"] = 140
    return selected


def minmax(s: pd.Series) -> pd.Series:
    lo, hi = float(s.min()), float(s.max())
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        return pd.Series(np.zeros(len(s)), index=s.index, dtype=float)
    return (s.astype(float) - lo) / (hi - lo)


def annuity_present_value(value: float, years: int, rate: float) -> float:
    return sum(value / ((1.0 + rate) ** year) for year in range(1, years + 1))


def feasible(row: pd.Series, grade: str) -> bool:
    r = RULES[grade]
    return (
        float(row["SOH_pred"]) >= r.min_soh
        and float(row["RUL_lower"]) >= r.min_rul_lower
        and float(row["uncertainty_width"]) <= r.max_uncertainty
    )


def grade_npv(row: pd.Series, grade: str, uncertainty_norm: float,
              benefit_mult: float = 1.0, cost_mult: float = 1.0) -> float:
    r = RULES[grade]
    annual_net = r.annual_benefit * benefit_mult - (
        r.annual_om_cost + r.annual_loss_cost
    ) * cost_mult
    pv_operating = annuity_present_value(annual_net, r.service_years, ECON["discount_rate"])
    # 不确定性越大，预留的风险准备金越高；靠近门槛时再增加安全边际准备金。
    soh_margin = max(0.0, (float(row["SOH_pred"]) - r.min_soh) / max(1e-9, 1.0 - r.min_soh))
    rul_margin = max(0.0, (float(row["RUL_lower"]) - r.min_rul_lower) / max(r.min_rul_lower, 1.0))
    margin_risk = 1.0 - min(1.0, 0.5 * soh_margin + 0.5 * rul_margin)
    risk_reserve = r.risk_reserve_rate * pv_operating * (0.65 * uncertainty_norm + 0.35 * margin_risk)
    upfront = ECON["inspection_cost"] * cost_mult + ECON["regroup_cost"] * cost_mult
    return pv_operating - risk_reserve - upfront


def screen_and_grade(df: pd.DataFrame, scenario: str, benefit_mult: float = 1.0,
                     cost_mult: float = 1.0) -> pd.DataFrame:
    out = df.copy()
    out["scenario"] = scenario
    out["Grade"] = "Reject"
    out["application"] = "材料回收/补充检测"
    out["decision_reason"] = "预测无效或缺少RUL置信下界"
    out["economic_npv"] = ECON["salvage_value"] - ECON["inspection_cost"] * cost_mult

    valid = out["prediction_valid"].fillna(False).astype(bool)
    valid &= out[["SOH_pred", "RUL_lower", "uncertainty_width"]].notna().all(axis=1)
    if valid.any():
        unc_norm = minmax(out.loc[valid, "uncertainty_width"])
        for idx in out.index[valid]:
            row = out.loc[idx]
            choices: List[Tuple[float, str]] = []
            for grade in GRADE_ORDER:
                if feasible(row, grade):
                    choices.append((grade_npv(row, grade, float(unc_norm.loc[idx]), benefit_mult, cost_mult), grade))
            if choices:
                value, grade = max(choices, key=lambda x: x[0])
                if value > out.at[idx, "economic_npv"]:
                    out.at[idx, "Grade"] = grade
                    out.at[idx, "application"] = RULES[grade].application
                    out.at[idx, "economic_npv"] = value
                    out.at[idx, "decision_reason"] = "满足安全阈值且该可行等级净现值最高"
            else:
                failed = []
                c = RULES["C"]
                if float(row["SOH_pred"]) < c.min_soh:
                    failed.append("SOH低于0.80")
                if float(row["RUL_lower"]) < c.min_rul_lower:
                    failed.append("RUL置信下界低于8循环")
                if float(row["uncertainty_width"]) > c.max_uncertainty:
                    failed.append("预测区间过宽")
                out.at[idx, "decision_reason"] = "；".join(failed) or "未通过安全筛选"
    return out


def balanced_sizes(n: int, max_size: int = 5) -> List[int]:
    if n <= 0:
        return []
    group_count = int(math.ceil(n / max_size))
    base, extra = divmod(n, group_count)
    return [base + 1] * extra + [base] * (group_count - extra)


def split_order(order: Sequence[int], sizes: Sequence[int]) -> List[List[int]]:
    groups, pos = [], 0
    for size in sizes:
        groups.append(list(order[pos:pos + size]))
        pos += size
    return groups


def group_metrics(df: pd.DataFrame, groups: Sequence[Sequence[int]]) -> Dict[str, float]:
    if not groups:
        return {"SOH_std": np.nan, "RUL_std": np.nan, "Unc_std": np.nan,
                "usable_life_ratio": np.nan}
    rows = []
    total_rul = max(float(df["RUL_lower"].sum()), 1e-9)
    usable = 0.0
    for ids in groups:
        g = df.loc[list(ids)]
        ddof = 1 if len(g) > 1 else 0
        rows.append((len(g), g["SOH_pred"].std(ddof=ddof), g["RUL_lower"].std(ddof=ddof),
                     g["uncertainty_width"].std(ddof=ddof)))
        usable += len(g) * float(g["RUL_lower"].min())
    n = sum(x[0] for x in rows)
    return {
        "SOH_std": sum(x[0] * x[1] for x in rows) / n,
        "RUL_std": sum(x[0] * x[2] for x in rows) / n,
        "Unc_std": sum(x[0] * x[3] for x in rows) / n,
        "usable_life_ratio": usable / total_rul,
    }


def objective(df: pd.DataFrame, groups: Sequence[Sequence[int]], weights: Dict[str, float]) -> float:
    if not groups:
        return 0.0
    ranges = {
        "SOH_pred": max(float(df["SOH_pred"].max() - df["SOH_pred"].min()), 1e-6),
        "RUL_lower": max(float(np.log1p(df["RUL_lower"]).max() - np.log1p(df["RUL_lower"]).min()), 1e-6),
        "uncertainty_width": max(float(np.log1p(df["uncertainty_width"]).max() - np.log1p(df["uncertainty_width"]).min()), 1e-6),
    }
    total, n = 0.0, len(df)
    for ids in groups:
        g = df.loc[list(ids)]
        if len(g) <= 1:
            continue
        d_soh = float(g["SOH_pred"].std()) / ranges["SOH_pred"]
        d_rul = float(np.log1p(g["RUL_lower"]).std()) / ranges["RUL_lower"]
        d_unc = float(np.log1p(g["uncertainty_width"]).std()) / ranges["uncertainty_width"]
        life_loss = 1.0 - float(g["RUL_lower"].min() / max(g["RUL_lower"].mean(), 1e-9))
        value = (
            weights["soh_consistency"] * d_soh
            + weights["rul_consistency"] * d_rul
            + weights["uncertainty_consistency"] * d_unc
            + weights["usable_life_loss"] * life_loss
        )
        total += len(g) / n * value
    return total


def optimize_grade(df: pd.DataFrame, max_size: int, weights: Dict[str, float], seed: int,
                   iterations: int) -> Tuple[List[List[int]], float]:
    if len(df) <= max_size:
        groups = [df.index.tolist()]
        return groups, objective(df, groups, weights)
    sizes = balanced_sizes(len(df), max_size)
    normalized_score = (
        0.35 * minmax(df["SOH_pred"])
        + 0.25 * minmax(df["RUL_lower"])
        - 0.15 * minmax(df["uncertainty_width"])
        + 0.25 * minmax(df["economic_npv"])
    )
    starts = [
        normalized_score.sort_values(ascending=False).index.to_list(),
        df["SOH_pred"].sort_values(ascending=False).index.to_list(),
        df["RUL_lower"].sort_values(ascending=False).index.to_list(),
    ]
    rng = np.random.default_rng(seed)
    # 三种排序起点加两种固定种子随机起点，再做确定性的最佳改进交换。
    for _ in range(2):
        starts.append(rng.permutation(df.index.to_numpy()).tolist())

    def canonical(order_to_fix: Sequence[int]) -> List[List[int]]:
        raw = split_order(order_to_fix, sizes)
        cooked = [sorted(g, key=lambda idx: str(df.at[idx, "battery_id"])) for g in raw]
        return sorted(cooked, key=lambda g: tuple(str(df.at[idx, "battery_id"]) for idx in g))

    best_groups, best_value, best_key = None, float("inf"), None
    for restart, start in enumerate(starts):
        order = list(start)
        current = objective(df, split_order(order, sizes), weights)
        for _ in range(max(1, min(iterations, 80))):
            candidate_value = current
            candidate_pair = None
            for i in range(len(order) - 1):
                for j in range(i + 1, len(order)):
                    order[i], order[j] = order[j], order[i]
                    trial = objective(df, split_order(order, sizes), weights)
                    order[i], order[j] = order[j], order[i]
                    if trial < candidate_value - 1e-12:
                        candidate_value, candidate_pair = trial, (i, j)
            if candidate_pair is None:
                break
            i, j = candidate_pair
            order[i], order[j] = order[j], order[i]
            current = candidate_value
        fixed = canonical(order)
        value = objective(df, fixed, weights)
        key = tuple(tuple(str(df.at[idx, "battery_id"]) for idx in g) for g in fixed)
        if value < best_value - 1e-12 or (abs(value - best_value) <= 1e-12 and (best_key is None or key < best_key)):
            best_value, best_groups, best_key = value, fixed, key
    assert best_groups is not None
    return best_groups, best_value


def optimize_all(decisions: pd.DataFrame, max_size: int, weights: Dict[str, float], seed: int,
                 iterations: int) -> Tuple[List[Tuple[str, List[int]]], float]:
    grouped: List[Tuple[str, List[int]]] = []
    weighted_obj, accepted_n = 0.0, int((decisions["Grade"] != "Reject").sum())
    for k, grade in enumerate(GRADE_ORDER):
        d = decisions[decisions["Grade"] == grade]
        if d.empty:
            continue
        groups, value = optimize_grade(d, max_size, weights, seed + 1009 * k, iterations)
        grouped.extend((grade, ids) for ids in groups)
        weighted_obj += len(d) / max(accepted_n, 1) * value
    return grouped, weighted_obj


def flatten_groups(decisions: pd.DataFrame, grouped: Sequence[Tuple[str, Sequence[int]]],
                   scenario: str) -> pd.DataFrame:
    rows = []
    counter = 0
    for grade, ids in grouped:
        counter += 1
        gid = f"{scenario[:3].upper()}-{grade}{counter:02d}"
        g = decisions.loc[list(ids)]
        for _, row in g.iterrows():
            rows.append({
                "scenario": scenario,
                "group_id": gid,
                "Grade": grade,
                "battery_id": row["battery_id"],
                "condition_id": row["condition_id"],
                "SOH_pred": row["SOH_pred"],
                "RUL_lower": row["RUL_lower"],
                "uncertainty_width": row["uncertainty_width"],
                "economic_npv": row["economic_npv"],
            })
    return pd.DataFrame(rows)


def groups_only(grouped: Sequence[Tuple[str, Sequence[int]]]) -> List[List[int]]:
    return [list(ids) for _, ids in grouped]


def baseline_comparison(decisions: pd.DataFrame, optimized: Sequence[Tuple[str, Sequence[int]]],
                        seed: int) -> pd.DataFrame:
    accepted = decisions[decisions["Grade"] != "Reject"]
    opt_groups = groups_only(optimized)
    records = []
    opt_metrics = group_metrics(accepted, opt_groups)
    records.append({"Method": "多目标优化", **opt_metrics, "objective": objective(accepted, opt_groups, BASE_WEIGHTS)})

    soh_groups: List[List[int]] = []
    for grade in GRADE_ORDER:
        d = accepted[accepted["Grade"] == grade].sort_values("SOH_pred", ascending=False)
        if d.empty:
            continue
        soh_groups.extend(split_order(d.index.tolist(), balanced_sizes(len(d), 5)))
    m = group_metrics(accepted, soh_groups)
    records.append({"Method": "仅SOH排序", **m, "objective": objective(accepted, soh_groups, BASE_WEIGHTS)})

    rng = np.random.default_rng(seed)
    random_metrics = []
    for _ in range(200):
        rand_groups: List[List[int]] = []
        for grade in GRADE_ORDER:
            d = accepted[accepted["Grade"] == grade]
            if d.empty:
                continue
            order = rng.permutation(d.index.to_numpy()).tolist()
            rand_groups.extend(split_order(order, balanced_sizes(len(d), 5)))
        mm = group_metrics(accepted, rand_groups)
        mm["objective"] = objective(accepted, rand_groups, BASE_WEIGHTS)
        random_metrics.append(mm)
    avg = pd.DataFrame(random_metrics).mean(numeric_only=True).to_dict()
    records.append({"Method": "随机分组（200次均值）", **avg})
    return pd.DataFrame(records)


def stable_uniform(identifier: str, scenario: str, seed: int) -> float:
    key = f"{seed}|{scenario}|{identifier}".encode("utf-8")
    raw = hashlib.sha256(key).digest()[:8]
    return int.from_bytes(raw, "big") / float(2**64 - 1)


def apply_scenario(df: pd.DataFrame, scenario: str, seed: int) -> pd.DataFrame:
    out = df.copy()
    valid = out["prediction_valid"].fillna(False).astype(bool)
    valid &= out[["SOH_pred", "RUL_lower", "uncertainty_width"]].notna().all(axis=1)
    if scenario == "baseline":
        return out
    valid_part = out.loc[valid]
    soh_vuln = minmax(0.91 - valid_part["SOH_pred"]).clip(0, 1)
    unc_vuln = minmax(valid_part["uncertainty_width"]).clip(0, 1)
    for idx in valid_part.index:
        row = out.loc[idx]
        rate = RATE_STRESS.get(str(row["condition_id"]), 0.65)
        u = stable_uniform(str(row["battery_id"]), scenario, seed)
        v = float(0.65 * soh_vuln.loc[idx] + 0.35 * unc_vuln.loc[idx])
        if scenario == "high_temperature":
            soh_drop = 0.006 + 0.010 * v + 0.003 * rate + 0.003 * u
            rul_factor = np.clip(0.84 - 0.13 * v - 0.06 * rate - 0.03 * u, 0.55, 0.84)
            unc_factor = 1.12 + 0.18 * v + 0.08 * u
        elif scenario == "frequent_high_rate":
            soh_drop = 0.004 + 0.007 * v + 0.008 * rate + 0.002 * u
            rul_factor = np.clip(0.91 - 0.20 * rate - 0.06 * v - 0.03 * u, 0.52, 0.86)
            unc_factor = 1.10 + 0.24 * rate + 0.06 * u
        elif scenario == "batch_dispersion":
            signed = 2.0 * u - 1.0
            batch_scale = {"2C": 0.8, "3C": 1.0, "R2.5": 1.15, "R3": 1.1,
                           "RW": 0.65, "Sim_satellite": 0.75}.get(str(row["condition_id"]), 1.0)
            soh_drop = 0.003 + 0.014 * batch_scale * max(0.0, -signed) + 0.003 * v
            rul_factor = np.clip(0.92 + 0.12 * signed - 0.08 * batch_scale - 0.05 * v, 0.62, 0.98)
            unc_factor = 1.22 + 0.28 * abs(signed) * batch_scale + 0.08 * v
        else:
            raise ValueError(f"未知场景: {scenario}")
        out.at[idx, "SOH_pred"] = max(0.0, float(row["SOH_pred"]) - soh_drop)
        out.at[idx, "RUL_lower"] = max(0.0, float(row["RUL_lower"]) * float(rul_factor))
        out.at[idx, "uncertainty_width"] = float(row["uncertainty_width"]) * float(unc_factor)
    return out


def pair_retention(base: pd.DataFrame, scenario: pd.DataFrame) -> float:
    def pairs(d: pd.DataFrame) -> set:
        out = set()
        for _, g in d.groupby("group_id"):
            ids = sorted(g["battery_id"].tolist())
            out.update((ids[i], ids[j]) for i in range(len(ids)) for j in range(i + 1, len(ids)))
        return out
    p0, p1 = pairs(base), pairs(scenario)
    return len(p0 & p1) / max(len(p0), 1)


def run_sensitivity(base_df: pd.DataFrame, decisions: pd.DataFrame, seed: int,
                    iterations: int) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    weight_sets = [
        ("基准", 0.35, 0.25, 0.15, 0.25),
        ("SOH偏重", 0.50, 0.18, 0.12, 0.20),
        ("RUL偏重", 0.25, 0.42, 0.13, 0.20),
        ("不确定性偏重", 0.28, 0.20, 0.32, 0.20),
        ("寿命利用偏重", 0.25, 0.20, 0.10, 0.45),
    ]
    wrows = []
    for i, (name, ws, wr, wu, wl) in enumerate(weight_sets):
        w = {"soh_consistency": ws, "rul_consistency": wr,
             "uncertainty_consistency": wu, "usable_life_loss": wl}
        grouped, obj = optimize_all(decisions, 5, w, seed + 1301 * i, max(20, iterations // 2))
        m = group_metrics(decisions[decisions["Grade"] != "Reject"], groups_only(grouped))
        wrows.append({"setting": name, **w, **m, "weighted_objective": obj})

    srows = []
    for size in (4, 5, 6):
        grouped, obj = optimize_all(decisions, size, BASE_WEIGHTS, seed + 1709 * size,
                                    max(20, iterations // 2))
        m = group_metrics(decisions[decisions["Grade"] != "Reject"], groups_only(grouped))
        srows.append({"max_group_size": size, "group_count": len(grouped), **m,
                      "weighted_objective": obj})

    erows = []
    for benefit_mult in (0.8, 1.0, 1.2):
        for cost_mult in (0.8, 1.0, 1.2):
            d = screen_and_grade(base_df, f"econ_{benefit_mult}_{cost_mult}", benefit_mult, cost_mult)
            erows.append({
                "benefit_multiplier": benefit_mult,
                "cost_multiplier": cost_mult,
                "accepted_count": int((d["Grade"] != "Reject").sum()),
                "total_npv": float(d["economic_npv"].sum()),
            })
    return pd.DataFrame(wrows), pd.DataFrame(srows), pd.DataFrame(erows)


def make_figures(out: Path, decisions: pd.DataFrame, comparison: pd.DataFrame,
                 scenario_summary: pd.DataFrame, group_assignments: pd.DataFrame,
                 weight_sens: pd.DataFrame, size_sens: pd.DataFrame,
                 econ_sens: pd.DataFrame) -> None:
    colors = {"A": "#1B998B", "B": "#2D7DD2", "C": "#F4A261", "Reject": "#D1495B"}
    counts = decisions["Grade"].value_counts().reindex(["A", "B", "C", "Reject"], fill_value=0)
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    display_grades = ["A", "B", "C", "淘汰/复检"]
    bars = ax.bar(display_grades, counts.values, color=[colors[x] for x in counts.index], width=0.65)
    for b, count in zip(bars, counts.values):
        ax.text(b.get_x() + b.get_width()/2, b.get_height() + 0.35,
                f"{count}块\n{count/len(decisions):.1%}", ha="center", va="bottom", fontsize=10)
    ax.set_ylabel("电池数量/块")
    ax.set_title("安全阈值与经济性联合筛选结果")
    ax.set_ylim(0, max(counts.values) * 1.22)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(out / "fig1_grade_distribution.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    metrics = ["SOH_std", "RUL_std", "Unc_std"]
    titles = ["组内SOH标准差", "组内RUL下界标准差", "组内不确定性标准差"]
    fig, axes = plt.subplots(1, 3, figsize=(12.5, 3.8))
    for ax, metric, title in zip(axes, metrics, titles):
        vals = comparison.set_index("Method")[metric]
        bars = ax.bar(range(len(vals)), vals.values, color=["#1B998B", "#F4A261", "#A9A9A9"])
        ax.set_xticks(range(len(vals)), ["多目标", "仅SOH", "随机"], rotation=12)
        ax.set_title(title)
        ax.spines[["top", "right"]].set_visible(False)
        for b, value in zip(bars, vals.values):
            ax.text(b.get_x()+b.get_width()/2, b.get_height(), f"{value:.3g}",
                    ha="center", va="bottom", fontsize=8)
    fig.suptitle("基准场景编组一致性对比（越低越好）", y=1.02, fontsize=14)
    fig.tight_layout()
    fig.savefig(out / "fig2_method_comparison.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    scen = scenario_summary.copy()
    labels = ["基准", "长期高温", "频繁大倍率", "批次差异"]
    fig, axes = plt.subplots(1, 3, figsize=(13, 4))
    axes[0].bar(labels, scen["accepted_count"], color="#2D7DD2")
    axes[0].set_title("通过安全筛选数量")
    axes[0].set_ylabel("块")
    axes[1].bar(labels, scen["total_npv"], color="#1B998B")
    axes[1].set_title("方案总净现值（情景量纲）")
    axes[1].set_ylabel("情景价值单位")
    axes[2].bar(labels, 100 * scen["pair_change_rate"], color="#E76F51")
    axes[2].set_title("相对基准的同组关系变化")
    axes[2].set_ylabel("%")
    for ax in axes:
        ax.tick_params(axis="x", rotation=18)
        ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(out / "fig3_scenario_robustness.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    base_groups = group_assignments[group_assignments["scenario"] == "baseline"]
    fig, axes = plt.subplots(1, 3, figsize=(13, 4))
    for ax, col, title in zip(axes, ["SOH_pred", "RUL_lower", "uncertainty_width"],
                              ["SOH", "RUL置信下界", "不确定性区间宽度"]):
        data = [g[col].values for _, g in base_groups.groupby("group_id", sort=False)]
        labels_g = [x for x, _ in base_groups.groupby("group_id", sort=False)]
        # ``labels`` is compatible with the older Matplotlib bundled in the
        # documented reproduction environment; newer releases also accept it.
        ax.boxplot(data, labels=labels_g, showfliers=True)
        ax.set_title(title)
        ax.tick_params(axis="x", rotation=45, labelsize=7)
        ax.grid(axis="y", alpha=0.2)
    fig.suptitle("基准场景优化编组的组内分布", y=1.02, fontsize=14)
    fig.tight_layout()
    fig.savefig(out / "fig4_group_boxplots.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].plot(weight_sens["setting"], weight_sens["usable_life_ratio"], "o-", color="#2D7DD2")
    axes[0].set_title("权重设定对可用寿命率的影响")
    axes[0].set_ylabel("可用寿命率")
    axes[0].tick_params(axis="x", rotation=25)
    axes[0].grid(alpha=0.25)
    axes[1].plot(size_sens["max_group_size"], size_sens["weighted_objective"], "s-", color="#E76F51")
    axes[1].set_title("最大组规模敏感性")
    axes[1].set_xlabel("每组最大电池数")
    axes[1].set_ylabel("加权目标值（越低越好）")
    axes[1].grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(out / "fig5_parameter_sensitivity.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    pivot = econ_sens.pivot(index="cost_multiplier", columns="benefit_multiplier", values="total_npv")
    fig, ax = plt.subplots(figsize=(6.4, 4.8))
    im = ax.imshow(pivot.values, cmap="YlGnBu", aspect="auto")
    ax.set_xticks(range(len(pivot.columns)), [f"{x:.0%}" for x in pivot.columns])
    ax.set_yticks(range(len(pivot.index)), [f"{x:.0%}" for x in pivot.index])
    ax.set_xlabel("收益系数")
    ax.set_ylabel("成本系数")
    ax.set_title("经济参数敏感性：方案总净现值")
    for i in range(len(pivot.index)):
        for j in range(len(pivot.columns)):
            ax.text(j, i, f"{pivot.iloc[i,j]:.0f}", ha="center", va="center", fontsize=9)
    fig.colorbar(im, ax=ax, label="情景价值单位")
    fig.tight_layout()
    fig.savefig(out / "fig6_economic_sensitivity.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    font = configure_chinese_font()
    df = pd.read_csv(args.input)
    required = {"battery_id", "condition_id", "SOH_pred", "RUL_lower",
                "uncertainty_width", "prediction_valid"}
    missing = sorted(required - set(df.columns))
    if missing:
        raise ValueError(f"输入缺少字段: {missing}")
    if df["battery_id"].duplicated().any():
        raise ValueError("battery_id 必须唯一")

    scenarios = ["baseline", "high_temperature", "frequent_high_rate", "batch_dispersion"]
    all_decisions, all_groups, summaries = [], [], []
    base_group_df = None
    base_comparison = None
    for i, scenario in enumerate(scenarios):
        scenario_df = apply_scenario(df, scenario, args.seed)
        decisions = screen_and_grade(scenario_df, scenario)
        grouped, obj = optimize_all(decisions, 5, BASE_WEIGHTS, args.seed + i * 7919, args.iterations)
        group_df = flatten_groups(decisions, grouped, scenario)
        if scenario == "baseline":
            base_group_df = group_df.copy()
            base_comparison = baseline_comparison(decisions, grouped, args.seed)
        retention = 1.0 if scenario == "baseline" else pair_retention(base_group_df, group_df)
        accepted = decisions[decisions["Grade"] != "Reject"]
        gm = group_metrics(accepted, groups_only(grouped))
        counts = decisions["Grade"].value_counts()
        summaries.append({
            "scenario": scenario,
            "valid_prediction_count": int(decisions["prediction_valid"].fillna(False).sum()),
            "accepted_count": int(len(accepted)),
            "rejected_count": int((decisions["Grade"] == "Reject").sum()),
            "A_count": int(counts.get("A", 0)),
            "B_count": int(counts.get("B", 0)),
            "C_count": int(counts.get("C", 0)),
            "group_count": len(grouped),
            "SOH_std": gm["SOH_std"],
            "RUL_std": gm["RUL_std"],
            "Unc_std": gm["Unc_std"],
            "usable_life_ratio": gm["usable_life_ratio"],
            "weighted_objective": obj,
            "total_npv": float(decisions["economic_npv"].sum()),
            "pair_retention_rate": retention,
            "pair_change_rate": 1.0 - retention,
        })
        all_decisions.append(decisions)
        all_groups.append(group_df)

    assert base_group_df is not None and base_comparison is not None
    scenario_summary = pd.DataFrame(summaries)
    decision_all = pd.concat(all_decisions, ignore_index=True)
    group_all = pd.concat(all_groups, ignore_index=True)
    base_decisions = all_decisions[0]
    weight_sens, size_sens, econ_sens = run_sensitivity(df, base_decisions, args.seed, args.iterations)

    base_decisions.to_csv(args.output / "battery_screening_baseline.csv", index=False, encoding="utf-8-sig")
    decision_all.to_csv(args.output / "scenario_battery_decisions.csv", index=False, encoding="utf-8-sig")
    group_all.to_csv(args.output / "group_assignments_all_scenarios.csv", index=False, encoding="utf-8-sig")
    base_comparison.to_csv(args.output / "method_comparison.csv", index=False, encoding="utf-8-sig")
    scenario_summary.to_csv(args.output / "scenario_summary.csv", index=False, encoding="utf-8-sig")
    weight_sens.to_csv(args.output / "sensitivity_weights.csv", index=False, encoding="utf-8-sig")
    size_sens.to_csv(args.output / "sensitivity_group_size.csv", index=False, encoding="utf-8-sig")
    econ_sens.to_csv(args.output / "sensitivity_economics.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame([
        {"grade": grade, **asdict(rule)} for grade, rule in RULES.items()
    ]).to_csv(args.output / "grade_rules_and_economics.csv", index=False, encoding="utf-8-sig")

    make_figures(args.output, base_decisions, base_comparison, scenario_summary,
                 group_all, weight_sens, size_sens, econ_sens)
    metadata = {
        "random_seed": args.seed,
        "deterministic_exchange_pass_limit": args.iterations,
        "input_file": str(args.input.resolve()),
        "input_rows": len(df),
        "input_sha256": hashlib.sha256(args.input.read_bytes()).hexdigest(),
        "rul_bound_type": args.rul_bound_type,
        "matplotlib_chinese_font": font,
        "grade_rules": {k: asdict(v) for k, v in RULES.items()},
        "economic_parameters": ECON,
        "objective_weights": BASE_WEIGHTS,
        "notes": [
            "经济参数为方案间比较用情景参数，不代表市场报价。",
            "场景扰动基于预测字段和 condition_id 构造，属于可复现实验而非实测极端工况。",
            "A/B/C为梯次利用优先级，投运前仍需容量、内阻、绝缘和热安全复检。",
            "empirical为十成员经验区间；residual-stress为19只85% EOL截断样本的绝对残差扩展，仅作压力测试。",
        ],
    }
    (args.output / "run_metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    print(scenario_summary.to_string(index=False))
    print(f"\n完成：结果已写入 {args.output.resolve()}")


if __name__ == "__main__":
    main()
