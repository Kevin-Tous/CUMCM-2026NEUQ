"""Regenerate every bitmap used by paper/main.tex with Chinese annotations.

Professional abbreviations (SOH, RUL, MAE, RMSE, MAPE, XGBoost, DCIR,
DOD, NCA and NCM) are intentionally retained.
"""
from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
A_DATA = ROOT / "results/degradation/data"
A_TABLE = ROOT / "results/degradation/tables"
A_FIG = ROOT / "results/degradation/figures"
U_FIG = ROOT / "results/degradation/uconn"
B = ROOT / "results/prediction/tables"
B_FIG = ROOT / "results/prediction/figures"
GAP = ROOT / "results/validation"
C_DATA = ROOT / "results/screening/baseline"
C_FIG = ROOT / "results/screening/figures"

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 140

STRATEGY = {
    "GEO_satellite_profile": "GEO卫星工况",
    "fixed_2C_charge_1C_discharge_full": "固定2C充电/1C放电",
    "fixed_3C_charge_1C_discharge_full": "固定3C充电/1C放电",
    "random_walk_partial": "随机游走部分放电",
    "variable_discharge_rate_full": "变倍率完全放电",
    "variable_discharge_rate_partial": "变倍率部分放电",
}
FACTORS = {
    "cycle_fraction": "循环位置",
    "strategy": "充电策略",
    "temperature_C": "温度",
    "temperature_rise_C": "温升",
    "discharge_rate_C": "放电倍率",
    "charge_rate_C": "充电倍率",
    "DOD_proxy": "DOD代理",
    "chemistry": "材料体系",
    "rate_C": "倍率",
    "cycle": "循环次数",
    "C_rate": "倍率",
    "DOD": "放电深度DOD",
    "charge_strategy_factor": "充电策略因子",
}
FEATURES = {
    "CV Q": "CV容量",
    "CV charge time": "CV充电时间",
    "EFC": "等效全循环EFC",
    "current entropy": "电流熵",
    "current slope": "电流斜率",
    "voltage slope": "电压斜率",
    "charge_rate_C": "充电倍率",
    "cycle": "循环次数",
    "voltage skewness": "电压偏度",
    "voltage kurtosis": "电压峰度",
    "voltage mean": "电压均值",
    "DOD": "放电深度DOD",
    "CC Q": "CC容量",
    "voltage entropy": "电压熵",
    "current skewness": "电流偏度",
}


def save(fig, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def degradation_figures() -> None:
    summary = pd.read_csv(A_TABLE / "dataset_summary.csv")
    independent = summary[summary.dataset != "NASA_dqdv"].copy()
    fig, ax1 = plt.subplots(figsize=(8.2, 4.6))
    x = np.arange(len(independent)); width = 0.36
    ax1.bar(x - width / 2, independent.independent_cells, width, color="#2878B5", label="独立电芯数")
    ax1.bar(x + width / 2, independent.censored_cells, width, color="#7FB3D5", label="右删失电芯数")
    ax1.set_xticks(x, independent.dataset)
    ax1.set_ylabel("独立电芯数/只")
    ax2 = ax1.twinx()
    ax2.plot(x, independent.cycles, color="#D95319", marker="o", linewidth=2, label="循环记录数")
    ax2.set_ylabel("循环记录数/条")
    ax1.set_title("公开电池数据集规模")
    h1, l1 = ax1.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, loc="upper center", ncol=3, fontsize=8, frameon=False)
    save(fig, A_FIG / "fig01_dataset_landscape.png")

    xj = pd.read_csv(A_DATA / "xjtu_analysis_table.csv")
    strategies = sorted(xj.strategy.unique())
    colors = dict(zip(strategies, plt.cm.tab10(np.linspace(0, 1, len(strategies)))))
    fig, ax = plt.subplots(figsize=(8.4, 5.0))
    for (_, strategy), g in xj.groupby(["battery_id", "strategy"]):
        ax.plot(g.cycle, g.SOH, color=colors[strategy], alpha=0.28, linewidth=0.75)
    for strategy, g in xj.groupby("strategy"):
        q = g.assign(bin=(g.cycle_fraction * 100).round()).groupby("bin").agg(cycle=("cycle", "median"), SOH=("SOH", "median"))
        ax.plot(q.cycle, q.SOH, color=colors[strategy], linewidth=2.2, label=STRATEGY.get(strategy, strategy))
    ax.axhline(0.8, color="black", linestyle="--", linewidth=1, label="SOH=0.80")
    ax.set(xlabel="循环次数", ylabel="SOH", title="XJTU全寿命容量轨迹")
    ax.legend(fontsize=7, ncol=2)
    save(fig, A_FIG / "fig02_xjtu_trajectories.png")

    stages = pd.read_csv(A_TABLE / "xjtu_degradation_stages.csv")
    staged = pd.read_csv(A_DATA / "xjtu_staged_curves.csv")
    picks = stages.assign(delta=(stages.cycle_life_observed - stages.groupby("batch_id").cycle_life_observed.transform("median")).abs()).sort_values("delta").groupby("batch_id").head(1)
    fig, axes = plt.subplots(2, 3, figsize=(11, 6.2), sharey=True)
    for ax, row in zip(axes.flat, picks.itertuples()):
        g = staged[staged.battery_id == row.battery_id]
        ax.scatter(g.cycle, g.SOH, s=5, alpha=0.38, color="#7F7F7F")
        ax.plot(g.cycle, g.SOH_smooth, color="#2878B5", linewidth=1.7)
        ax.axvline(row.break1_cycle, color="#EDB120", linestyle="--")
        ax.axvline(row.break2_cycle, color="#D95319", linestyle="--")
        ax.set_title(f"{str(row.batch_id).replace('Batch-', '批次')}：{row.battery_id}", fontsize=9)
        ax.set_xlabel("循环次数")
    axes[0, 0].set_ylabel("SOH"); axes[1, 0].set_ylabel("SOH")
    fig.suptitle("数据驱动的三阶段退化划分", fontweight="bold")
    save(fig, A_FIG / "fig03_stage_examples.png")

    fig, ax = plt.subplots(figsize=(7.2, 4.2)); bins = np.linspace(0, 1, 15)
    ax.hist(stages.break1_fraction, bins=bins, alpha=0.72, label="阶段I→II", color="#EDB120")
    ax.hist(stages.break2_fraction, bins=bins, alpha=0.65, label="阶段II→III", color="#D95319")
    ax.set(xlabel="占观测寿命比例", ylabel="电芯数量/只", title="退化阶段转折点分布"); ax.legend()
    save(fig, A_FIG / "fig04_stage_break_distribution.png")

    unified = pd.read_csv(A_DATA / "unified_capacity_curves.csv")
    tju = unified[(unified.dataset == "TJU") & unified.SOH.between(0.55, 1.15)].copy()
    tju["life_bin"] = (tju.cycle_fraction * 20).round() / 20
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.2), sharey=True)
    for ax, chemistry in zip(axes, ["NCA", "NCM"]):
        q = tju[tju.chemistry == chemistry].groupby(["temperature_C", "life_bin"], as_index=False).SOH.median()
        for temp, g in q.groupby("temperature_C"):
            ax.plot(g.life_bin, g.SOH, marker="o", markersize=2.5, label=f"{temp:.0f}℃")
        ax.set_title(chemistry); ax.set_xlabel("观测寿命比例"); ax.legend(fontsize=8)
    axes[0].set_ylabel("SOH中位数"); fig.suptitle("TJU实测温度对比", fontweight="bold")
    save(fig, A_FIG / "fig05_tju_temperature.png")

    ximp = pd.read_csv(A_TABLE / "xjtu_factor_importance.csv").set_index("factor")["weight"]
    timp = pd.read_csv(A_TABLE / "tju_factor_importance.csv").set_index("factor")["weight"]
    simp = pd.read_csv(A_TABLE / "simulation_global_sensitivity.csv").set_index("factor")["normalized_weight"]
    # Cycle position is a degradation-progress coordinate, not an external
    # stress parameter.  Keep its full-model weight in the audit CSV, but
    # renormalize only external dimensions for the Q1 influence figure.
    panels = [
        ("XJTU条件预测贡献", pd.Series({
            "充电策略": ximp.get("strategy", 0),
            "温度及温升": ximp.get("temperature_C", 0) + ximp.get("temperature_rise_C", 0),
            "充放电倍率": ximp.get("charge_rate_C", 0) + ximp.get("discharge_rate_C", 0),
            "放电深度DOD": ximp.get("DOD_proxy", 0),
        }), "#2878B5"),
        ("TJU条件预测贡献", pd.Series({
            "温度": timp.get("temperature_C", 0),
            "材料体系": timp.get("chemistry", 0),
            "倍率": timp.get("rate_C", 0),
        }), "#2A9D8F"),
        ("受控情景敏感度", pd.Series({
            "倍率": simp.get("C_rate", 0),
            "放电深度DOD": simp.get("DOD", 0),
            "温度": simp.get("temperature_C", 0),
            "充电策略": simp.get("charge_strategy_factor", 0),
        }), "#D95319"),
    ]
    evidence_rows = []
    fig, axes = plt.subplots(2, 2, figsize=(11.4, 8.0))
    for ax, (title, values, color) in zip([axes[0, 0], axes[0, 1], axes[1, 0]], panels):
        values = values.clip(lower=0); weights = values / values.sum() if values.sum() else values
        weights = weights.sort_values()
        ax.barh(weights.index, weights.values, color=color)
        for y, (factor, value) in enumerate(weights.items()):
            if value >= 0.008:
                ax.text(value + 0.012, y, f"{value:.1%}", va="center", fontsize=8)
            elif title.startswith("XJTU") and factor == "放电深度DOD":
                ax.text(0.012, y, "与策略共线，独立效应不可辨", va="center", fontsize=7.5, color="#666666")
            elif title.startswith("TJU") and factor == "倍率":
                ax.text(0.012, y, "样本失衡，独立效应不可辨", va="center", fontsize=7.5, color="#666666")
        axis_label = "统一情景空间综合影响占比" if title.startswith("受控") else "外部因素内归一化贡献"
        ax.set_xlim(0, max(1.0, float(weights.max()) * 1.18)); ax.set_xlabel(axis_label); ax.set_title(title)
        evidence_rows.extend({"evidence_layer": title, "factor": k, "external_normalized_weight": float(v)} for k, v in weights.items())

    ax = axes[1, 1]
    row_labels = ["倍率", "DOD", "温度", "充电策略"]
    col_labels = ["XJTU", "TJU", "UConn", "受控模型"]
    # 0=未覆盖，1=共线/弱辨识，2=联合方向支持，3=可辨识或独立受控。
    matrix = np.array([
        [2, 1, 2, 3],
        [1, 0, 2, 3],
        [3, 3, 0, 3],
        [3, 0, 0, 3],
    ])
    from matplotlib.colors import ListedColormap
    cmap = ListedColormap(["#ECECEC", "#F4C95D", "#70A1D7", "#4CAF70"])
    ax.imshow(matrix, cmap=cmap, vmin=-0.5, vmax=3.5, aspect="auto")
    ax.set_xticks(range(len(col_labels)), col_labels)
    ax.set_yticks(range(len(row_labels)), row_labels)
    cell_text = {0: "未覆盖", 1: "不可独辨", 2: "联合支持", 3: "可辨/受控"}
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            ax.text(j, i, cell_text[int(matrix[i, j])], ha="center", va="center", fontsize=8,
                    color="white" if matrix[i, j] == 3 else "#333333")
    ax.set_title("各数据源与占比结论的证据关联")
    ax.set_xlabel("证据来源")
    ax.set_xticks(np.arange(-.5, len(col_labels), 1), minor=True)
    ax.set_yticks(np.arange(-.5, len(row_labels), 1), minor=True)
    ax.grid(which="minor", color="white", linewidth=1.5)
    ax.tick_params(which="minor", bottom=False, left=False)
    fig.suptitle("问题一多维影响因素：观测贡献、综合占比与外部证据", fontsize=12, fontweight="bold")
    pd.DataFrame(evidence_rows).to_csv(A_TABLE / "multidimensional_factor_evidence.csv", index=False, encoding="utf-8-sig")
    save(fig, A_FIG / "fig06_factor_importance.png")

    sim = pd.read_csv(A_DATA / "simulated_capacity_resistance_scenarios.csv")
    labels = {"baseline":"基准工况","cold_0C":"低温0℃","hot_45C":"高温45℃","fast_3C":"3C大倍率","shallow_DOD50":"浅放电50% DOD","deep_DOD100":"深放电100% DOD","aggressive_charge":"激进充电代理"}
    order = list(labels); colors = dict(zip(order, plt.get_cmap("tab10").colors[:len(order)]))
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    for name in order:
        g = sim[sim.scenario == name]
        axes[0].plot(g.cycle, g.SOH_simulated, label=labels[name], color=colors[name], linewidth=1.6)
        axes[1].plot(g.cycle, g.DCIR_proxy_mOhm, label=labels[name], color=colors[name], linewidth=1.6)
    axes[0].axhline(0.8, color="black", linestyle="--", linewidth=1)
    axes[0].set(xlabel="循环次数", ylabel="模拟SOH", title="模拟容量衰减")
    axes[1].set(xlabel="循环次数", ylabel="等效DCIR半经验值/mΩ", title="等效内阻变化（半经验模型）")
    axes[1].legend(fontsize=7, ncol=2, title="工况情景", title_fontsize=7)
    save(fig, A_FIG / "fig07_joint_simulation.png")

    sens = pd.read_csv(A_TABLE / "simulation_global_sensitivity.csv").sort_values("normalized_weight")
    sens["标签"] = sens.factor.map(FACTORS).fillna(sens.factor)
    fig, ax = plt.subplots(figsize=(7.2, 4.0))
    ax.barh(sens["标签"], sens.normalized_weight, color=np.where(sens.spearman_rho >= 0, "#D95319", "#2878B5"))
    ax.set(xlabel="归一化置换权重", title="模拟容量损失的全局敏感性")
    save(fig, A_FIG / "fig08_simulation_sensitivity.png")


def uconn() -> None:
    d = pd.read_csv(U_FIG / "uconn_rpt_capacity_dcir_with_median.csv")
    rho = d.SOH_C3.rank().corr(d.DCIR_median_mOhm.rank())
    fig, axes = plt.subplots(1, 2, figsize=(10.2, 4.0))
    for bid, g in d.groupby("battery_id"):
        axes[0].plot(g.rpt_index, g.SOH_C3, marker="o", ms=2.5, lw=1.1, label=bid.replace("UCONN:", ""))
    axes[0].set(xlabel="RPT序号", ylabel="SOH（C/3容量）", title="UConn实测容量退化"); axes[0].legend(ncol=2, fontsize=7, frameon=False)
    sc = axes[1].scatter(d.SOH_C3, d.DCIR_median_mOhm, c=d.rpt_index, cmap="viridis", s=18, alpha=.72)
    axes[1].set(xlabel="SOH（C/3容量）", ylabel="DCIR中位数/mΩ", title="实测SOH与DCIR关系")
    fig.colorbar(sc, ax=axes[1], label="RPT序号")
    fig.suptitle(f"UConn外部实测佐证：斯皮尔曼相关系数ρ={rho:.3f}", fontsize=11)
    save(fig, U_FIG / "uconn_capacity_dcir_evidence.png")

    # The raw cycling ZIP is intentionally excluded from the delivery package.
    # Replot the auditable joint-protocol comparison from the frozen derived
    # cell/group tables generated by uconn_protocol_effect.py.
    cells = pd.read_csv(U_FIG / "uconn_protocol_cell_summary.csv")
    groups = pd.read_csv(U_FIG / "uconn_protocol_group_summary.csv")
    palette = {"G3": "#2878B5", "G5": "#D95319"}
    fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.4))
    metrics = ["charge_rate_C_mean", "discharge_rate_C_mean", "DOD_mean"]
    labels = ["充电倍率/C", "放电倍率/C", "DOD"]
    x = np.arange(len(labels)); width = 0.34
    for offset, row in zip((-width / 2, width / 2), groups.itertuples(index=False)):
        values = [getattr(row, metric) for metric in metrics]
        bars = axes[0].bar(x + offset, values, width, label=row.protocol_group,
                           color=palette[row.protocol_group])
        for bar, value in zip(bars, values):
            text = f"{value:.2f}" if value > 1 else f"{value:.1%}"
            axes[0].text(bar.get_x() + bar.get_width() / 2, value + 0.05,
                         text, ha="center", va="bottom", fontsize=8)
    axes[0].set_xticks(x, labels); axes[0].set_ylim(0, 5.4)
    axes[0].set_ylabel("实测协议参数"); axes[0].set_title("两组循环协议参数")
    axes[0].legend(title="协议组", frameon=False)
    order = ["G3", "G5"]
    means = groups.set_index("protocol_group").loc[order, "days_to_SOH80_mean"]
    sds = groups.set_index("protocol_group").loc[order, "days_to_SOH80_sd"]
    axes[1].bar(order, means, yerr=sds, capsize=5,
                color=[palette[group] for group in order], alpha=0.82)
    rng = np.random.default_rng(2026)
    for xi, group in enumerate(order):
        values = cells.loc[cells.protocol_group == group, "days_to_SOH80"].to_numpy(float)
        axes[1].scatter(xi + rng.uniform(-0.06, 0.06, len(values)), values,
                        color="#222222", s=28, zorder=3)
    axes[1].set_ylabel("首次达到 SOH=0.80 的时间/天")
    axes[1].set_title("联合协议下的实测退化差异")
    axes[1].text(0.5, 0.03, "充/放电倍率与DOD同时变化；仅表示联合协议效应",
                 transform=axes[1].transAxes, ha="center", va="bottom",
                 fontsize=8, color="#555555")
    for ax in axes:
        ax.grid(axis="y", alpha=0.22)
    fig.suptitle("UConn G3/G5 倍率-DOD 联合协议实测对比", fontsize=12, fontweight="bold")
    save(fig, U_FIG / "uconn_joint_protocol_effect.png")


def prediction_figures() -> None:
    # Avoid a version-specific seaborn style name; explicit grids below keep
    # the paper figures reproducible on the documented older Matplotlib.
    plt.rcParams["axes.grid"] = True
    plt.rcParams["grid.alpha"] = 0.25
    comparison = pd.read_csv(B / "model_comparison.csv")
    fig, axes = plt.subplots(1, 3, figsize=(12, 3.6))
    for ax, metric, label in zip(axes, ("MAE", "RMSE", "MAPE"), ("MAE", "RMSE", "MAPE/%")):
        means = comparison[f"{metric}_mean" if metric != "MAPE" else "MAPE_mean_pct"]
        stds = comparison[f"{metric}_std" if metric != "MAPE" else "MAPE_std_pct"]
        ax.bar(comparison.model.str.upper(), means, yerr=stds, capsize=3, color="#3973ac")
        ax.set_ylabel(label); ax.tick_params(axis="x", rotation=30); ax.set_title("越低越好")
    fig.suptitle("五折留电池模型比较（误差棒为折间标准差）")
    save(fig, B_FIG / "model_comparison.png")

    curves = pd.read_csv(B / "representative_soh_curves.csv")
    fig, axes = plt.subplots(3, 2, figsize=(10, 10), sharey=True); flat = axes.ravel()
    groups = list(curves.groupby("battery_id", sort=False))
    for ax, (bid, g) in zip(flat, groups):
        g = g.sort_values("cycle"); ax.plot(g.cycle, g.SOH, label="真实值", lw=1.5); ax.plot(g.cycle, g.SOH_pred, label="预测值", lw=1.2)
        ax.fill_between(g.cycle, g.SOH_lower, g.SOH_upper, alpha=.18); ax.axhline(.8, color="k", ls="--", lw=.8)
        ax.set_title(bid.replace("XJTU:", ""), fontsize=9); ax.set_xlabel("循环次数"); ax.set_ylabel("SOH")
    for ax in flat[len(groups):]: ax.axis("off")
    flat[0].legend(fontsize=8); fig.suptitle("代表性电芯的XGBoost SOH轨迹")
    save(fig, B_FIG / "representative_soh_curves.png")

    rep = pd.read_csv(B / "representative_rul_intervals.csv"); y = np.arange(len(rep)); med = rep.rul_median.to_numpy(float)
    fig, ax = plt.subplots(figsize=(7.5, 4.2))
    ax.errorbar(med, y, xerr=np.vstack([med-rep.rul_lower.to_numpy(float), rep.rul_upper.to_numpy(float)-med]), fmt="o", capsize=4)
    ax.set_yticks(y, rep.battery_id.str.replace("XJTU:", "", regex=False)); ax.set_xlabel("预测RUL/循环"); ax.set_title("代表性电芯的XGBoost RUL经验区间")
    save(fig, B_FIG / "rul_intervals.png")

    importance = pd.read_csv(B / "feature_importance.csv").head(15).sort_values("importance_mean"); importance["标签"] = importance.feature.map(FEATURES).fillna(importance.feature)
    fig, ax = plt.subplots(figsize=(7.2, 5.5)); ax.barh(importance["标签"], importance.importance_mean, xerr=importance.importance_std, color="#3973ac", capsize=2)
    ax.set_xlabel("归一化增益重要度"); ax.set_title("XGBoost特征重要度（50个集成成员）")
    save(fig, B_FIG / "feature_importance.png")

    ab = pd.read_csv(B / "xgboost_ablation_summary.csv"); variant = {"16HI":"16HI","16HI+cycle":"16HI+循环","16HI+cycle+conditions":"16HI+循环+工况"}; labels = ab.variant.map(variant).fillna(ab.variant)
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.8))
    for ax, m in zip(axes, ("MAE", "RMSE")):
        ax.bar(labels, ab[f"{m}_mean"], yerr=ab[f"{m}_std"], capsize=3, color="#3973ac"); ax.set_ylabel(m); ax.tick_params(axis="x", rotation=12); ax.set_title(f"五折{m}（越低越好）")
    fig.suptitle("XGBoost输入消融（误差棒为折间标准差）")
    save(fig, B_FIG / "ablation_comparison.png")

    agg = pd.read_csv(B / "threshold_sensitivity_summary.csv")
    fig, ax = plt.subplots(figsize=(6.2, 4.2)); ax.plot(agg.threshold, agg["median"], marker="o"); ax.fill_between(agg.threshold, agg.q25, agg.q75, alpha=.2)
    ax.set_xticks(agg.threshold); ax.set(xlabel="SOH失效阈值", ylabel="预测RUL中位数/循环", title="RUL对SOH阈值的敏感性")
    save(fig, B_FIG / "threshold_sensitivity.png")


def gap() -> None:
    backtest = pd.read_csv(GAP / "rul_forward_backtest_detail.csv")
    stress = pd.read_csv(GAP / "xgboost_stress_coupling_summary.csv").sort_values("median_rul_change_pct")
    fig, axes = plt.subplots(1, 2, figsize=(10.4, 4.2))
    axes[0].scatter(backtest.true_rul, backtest.rul_median, s=34, color="#2878B5", alpha=.86)
    lim = max(float(backtest.true_rul.max()), float(backtest.rul_median.max())) * 1.05
    axes[0].plot([0, lim], [0, lim], "--", color="#555555", lw=1)
    axes[0].set(xlabel="85%寿命终点截断时的真实RUL/循环", ylabel="预测RUL/循环", title="RUL前向截断回测")
    labels = ["激进充电代理", "3C大倍率", "高温45℃", "深放电100% DOD", "低温0℃"]
    axes[1].barh(labels, stress.median_rul_change_pct, color="#D9534F"); axes[1].axvline(0, color="#444444", lw=.8)
    axes[1].set(xlabel="RUL中位数变化/%", title="应力修正后的XGBoost RUL")
    for ax in axes: ax.grid(alpha=.22)
    save(fig, GAP / "rul_backtest_and_stress_coupling.png")


def screening_figures() -> None:
    decisions = pd.read_csv(C_DATA / "battery_screening_baseline.csv")
    counts = decisions.Grade.value_counts().reindex(["A", "B", "C", "Reject"], fill_value=0)
    colors = ["#1B998B", "#2D7DD2", "#F4A261", "#D1495B"]
    fig, ax = plt.subplots(figsize=(7.2, 4.6)); bars = ax.bar(["A", "B", "C", "淘汰/复检"], counts.values, color=colors, width=.65)
    for b, count in zip(bars, counts.values): ax.text(b.get_x()+b.get_width()/2, b.get_height()+.35, f"{count}块\n{count/len(decisions):.1%}", ha="center", va="bottom", fontsize=10)
    ax.set_ylabel("电池数量/块"); ax.set_title("安全阈值与经济性联合筛选结果"); ax.set_ylim(0, max(counts.values)*1.22); ax.spines[["top","right"]].set_visible(False)
    save(fig, C_FIG / "fig1_grade_distribution.png")

    comparison = pd.read_csv(C_DATA / "method_comparison.csv")
    fig, axes = plt.subplots(1, 3, figsize=(12.5, 3.8))
    for ax, metric, title in zip(axes, ["SOH_std", "RUL_std", "Unc_std"], ["组内SOH标准差", "组内RUL下界标准差", "组内不确定性标准差"]):
        values = comparison[metric]
        bars = ax.bar(range(len(values)), values, color=["#1B998B", "#F4A261", "#A9A9A9"])
        ax.set_xticks(range(len(values)), ["多目标", "仅SOH", "随机"], rotation=12); ax.set_title(title)
        for bar, value in zip(bars, values): ax.text(bar.get_x()+bar.get_width()/2, bar.get_height(), f"{value:.3g}", ha="center", va="bottom", fontsize=8)
    fig.suptitle("基准场景编组一致性对比（越低越好）", y=1.02, fontsize=14)
    save(fig, C_FIG / "fig2_method_comparison.png")

    scen = pd.read_csv(C_DATA / "scenario_summary.csv"); labels = ["基准", "长期高温", "频繁大倍率", "批次差异"]
    fig, axes = plt.subplots(1, 3, figsize=(13, 4))
    axes[0].bar(labels, scen.accepted_count, color="#2D7DD2"); axes[0].set_title("通过安全筛选数量"); axes[0].set_ylabel("块")
    axes[1].bar(labels, scen.total_npv, color="#1B998B"); axes[1].set_title("方案总净现值（情景量纲）"); axes[1].set_ylabel("情景价值单位")
    axes[2].bar(labels, 100*scen.pair_change_rate, color="#E76F51"); axes[2].set_title("相对基准的同组关系变化"); axes[2].set_ylabel("百分比/%")
    for ax in axes: ax.tick_params(axis="x", rotation=18)
    save(fig, C_FIG / "fig3_scenario_robustness.png")

    ws = pd.read_csv(C_DATA / "sensitivity_weights.csv"); ss = pd.read_csv(C_DATA / "sensitivity_group_size.csv")
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].plot(ws.setting, ws.usable_life_ratio, "o-", color="#2D7DD2"); axes[0].set_title("权重设定对可用寿命率的影响"); axes[0].set_ylabel("可用寿命率"); axes[0].tick_params(axis="x", rotation=25)
    axes[1].plot(ss.max_group_size, ss.weighted_objective, "s-", color="#E76F51"); axes[1].set_title("最大组规模敏感性"); axes[1].set_xlabel("每组最大电池数"); axes[1].set_ylabel("加权目标值（越低越好）")
    save(fig, C_FIG / "fig5_parameter_sensitivity.png")

    es = pd.read_csv(C_DATA / "sensitivity_economics.csv"); pivot = es.pivot(index="cost_multiplier", columns="benefit_multiplier", values="total_npv")
    plt.rcParams["axes.grid"] = False
    fig, ax = plt.subplots(figsize=(6.4, 4.8)); ax.grid(False); im = ax.imshow(pivot.values, cmap="YlGnBu", aspect="auto")
    ax.set_xticks(range(len(pivot.columns)), [f"{x:.0%}" for x in pivot.columns]); ax.set_yticks(range(len(pivot.index)), [f"{x:.0%}" for x in pivot.index])
    ax.set_xlabel("收益系数"); ax.set_ylabel("成本系数"); ax.set_title("经济参数敏感性：方案总净现值")
    for i in range(len(pivot.index)):
        for j in range(len(pivot.columns)): ax.text(j, i, f"{pivot.iloc[i,j]:.0f}", ha="center", va="center", fontsize=9)
    fig.colorbar(im, ax=ax, label="情景价值单位")
    save(fig, C_FIG / "fig6_economic_sensitivity.png")


def main() -> None:
    degradation_figures(); uconn(); prediction_figures(); gap(); screening_figures()
    print("Regenerated all 22 bitmap figures referenced by paper/main.tex.")


if __name__ == "__main__":
    main()
