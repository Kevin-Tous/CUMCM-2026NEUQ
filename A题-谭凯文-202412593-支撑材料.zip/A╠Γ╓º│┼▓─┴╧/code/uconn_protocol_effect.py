"""Extract and analyse UConn Batch 1 Part 1 protocol effects.

The six local cells form two replicated joint-protocol groups.  Charge rate,
discharge rate and DOD all change between G3 and G5, so the output is a joint
protocol contrast and must not be interpreted as three independent causal
importance percentages.
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import re
import statistics
import zipfile
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


NOMINAL_CAPACITY_AH = 1.2


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--zip", type=Path, required=True, help="UConn Batch 1 Part 1 ZIP")
    parser.add_argument("--rpt", type=Path, required=True, help="Derived RPT capacity/DCIR CSV")
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def median_active(values: list[float]) -> float:
    active = [value for value in values if abs(value) > 0.05]
    return float(statistics.median(active)) if active else float("nan")


def extract_protocols(zip_path: Path) -> pd.DataFrame:
    rows: list[dict[str, float | str]] = []
    with zipfile.ZipFile(zip_path) as archive:
        names = [
            name for name in archive.namelist()
            if re.search(r"/cycling\s*1\.csv$", name, re.I)
        ]
        for name in sorted(names):
            cell = name.split("/")[-2]
            currents: dict[str, list[float]] = {"charge": [], "discharge": []}
            qmax = {"charge": 0.0, "discharge": 0.0}
            with archive.open(name) as raw:
                stream = io.TextIOWrapper(raw, encoding="utf-8-sig", newline="")
                for index, row in enumerate(csv.DictReader(stream)):
                    state = row["State"]
                    if "DChg" in state:
                        kind = "discharge"
                    elif "Chg" in state:
                        kind = "charge"
                    else:
                        continue
                    if index % 100 == 0:
                        currents[kind].append(float(row["Current(A)"]))
                    qmax[kind] = max(qmax[kind], float(row["Capacity(Ah)"]))
            charge_a = median_active(currents["charge"])
            discharge_a = median_active(currents["discharge"])
            rows.append({
                "cell_code": cell,
                "protocol_group": cell[:2],
                "charge_current_A": charge_a,
                "discharge_current_A": discharge_a,
                "charge_rate_C": charge_a / NOMINAL_CAPACITY_AH,
                "discharge_rate_C": abs(discharge_a) / NOMINAL_CAPACITY_AH,
                "charge_capacity_Ah": qmax["charge"],
                "discharge_capacity_Ah": qmax["discharge"],
                "DOD": qmax["discharge"] / qmax["charge"],
                "source_member": name,
            })
    result = pd.DataFrame(rows)
    if set(result["cell_code"]) != {"G3C1", "G3C2", "G3C3", "G5C1", "G5C2", "G5C3"}:
        raise ValueError("Expected exactly the six G3/G5 cells in Batch 1 Part 1")
    return result


def attach_life_metrics(protocols: pd.DataFrame, rpt_path: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    rpt = pd.read_csv(rpt_path, parse_dates=["test_date"]).sort_values(["battery_id", "test_date"])
    rpt["cell_code"] = rpt["cell_code"].astype(str)
    rpt["elapsed_days"] = (
        rpt["test_date"] - rpt.groupby("cell_code")["test_date"].transform("min")
    ).dt.total_seconds() / 86400
    life_rows = []
    for cell, group in rpt.groupby("cell_code", sort=True):
        crossing = group.loc[group["SOH_C3"] <= 0.80, "elapsed_days"]
        life_rows.append({
            "cell_code": cell,
            "rpt_records": int(len(group)),
            "days_to_SOH80": float(crossing.iloc[0]) if len(crossing) else np.nan,
            "final_observed_SOH": float(group["SOH_C3"].iloc[-1]),
        })
    cells = protocols.merge(pd.DataFrame(life_rows), on="cell_code", how="left", validate="one_to_one")
    groups = cells.groupby("protocol_group", as_index=False).agg(
        cells=("cell_code", "size"),
        charge_rate_C_mean=("charge_rate_C", "mean"),
        charge_rate_C_sd=("charge_rate_C", "std"),
        discharge_rate_C_mean=("discharge_rate_C", "mean"),
        discharge_rate_C_sd=("discharge_rate_C", "std"),
        DOD_mean=("DOD", "mean"),
        DOD_sd=("DOD", "std"),
        days_to_SOH80_mean=("days_to_SOH80", "mean"),
        days_to_SOH80_sd=("days_to_SOH80", "std"),
    )
    return cells, groups


def make_figure(cells: pd.DataFrame, groups: pd.DataFrame, output: Path) -> None:
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    palette = {"G3": "#2878B5", "G5": "#D95319"}
    fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.4))

    metrics = ["charge_rate_C_mean", "discharge_rate_C_mean", "DOD_mean"]
    labels = ["充电倍率/C", "放电倍率/C", "DOD"]
    x = np.arange(len(labels)); width = 0.34
    for offset, row in zip((-width / 2, width / 2), groups.itertuples(index=False)):
        values = [getattr(row, metric) for metric in metrics]
        bars = axes[0].bar(x + offset, values, width, label=row.protocol_group,
                           color=palette[row.protocol_group])
        for bar, value in zip(bars, values):
            text = f"{value:.2f}" if value > 1 else f"{value:.1%}"
            axes[0].text(bar.get_x() + bar.get_width() / 2, value + 0.05,
                         text, ha="center", va="bottom", fontsize=8)
    axes[0].set_xticks(x, labels)
    axes[0].set_ylim(0, 5.4)
    axes[0].set_ylabel("实测协议参数")
    axes[0].set_title("两组循环协议参数")
    axes[0].legend(title="协议组", frameon=False)

    order = ["G3", "G5"]
    means = groups.set_index("protocol_group").loc[order, "days_to_SOH80_mean"]
    sds = groups.set_index("protocol_group").loc[order, "days_to_SOH80_sd"]
    axes[1].bar(order, means, yerr=sds, capsize=5,
                color=[palette[group] for group in order], alpha=0.82)
    rng = np.random.default_rng(2026)
    for xi, group in enumerate(order):
        values = cells.loc[cells.protocol_group == group, "days_to_SOH80"].to_numpy(float)
        axes[1].scatter(xi + rng.uniform(-0.06, 0.06, len(values)), values,
                        color="#222222", s=28, zorder=3)
    axes[1].set_ylabel("首次达到 SOH=0.80 的时间/天")
    axes[1].set_title("联合协议下的实测退化差异")
    axes[1].text(0.5, 0.03,
                 "充/放电倍率与DOD同时变化；仅表示联合协议效应",
                 transform=axes[1].transAxes, ha="center", va="bottom",
                 fontsize=8, color="#555555")
    for ax in axes:
        ax.grid(axis="y", alpha=0.22)
    fig.suptitle("UConn G3/G5 倍率-DOD 联合协议实测对比", fontsize=12, fontweight="bold")
    fig.tight_layout()
    fig.savefig(output / "uconn_joint_protocol_effect.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    protocols = extract_protocols(args.zip)
    cells, groups = attach_life_metrics(protocols, args.rpt)
    cells.to_csv(args.output / "uconn_protocol_cell_summary.csv", index=False, encoding="utf-8-sig")
    groups.to_csv(args.output / "uconn_protocol_group_summary.csv", index=False, encoding="utf-8-sig")
    summary = {
        "cells": int(len(cells)),
        "groups": groups.to_dict(orient="records"),
        "interpretation": "Joint protocol contrast only; charge rate, discharge rate and DOD are confounded.",
    }
    (args.output / "uconn_protocol_effect_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    make_figure(cells, groups, args.output)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
