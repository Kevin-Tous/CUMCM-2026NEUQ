"""Generate auditable UConn capacity--DCIR evidence from the derived RPT table."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--input", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    return p.parse_args()


def spearman(x: pd.Series, y: pd.Series) -> float:
    pair = pd.concat([x, y], axis=1).dropna()
    return float(pair.iloc[:, 0].rank().corr(pair.iloc[:, 1].rank()))


def main() -> None:
    args = parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    d = pd.read_csv(args.input).sort_values(["battery_id", "rpt_index"])
    required = {
        "battery_id", "rpt_index", "SOH_C3",
        "DCIR_chg_median_mOhm", "DCIR_dchg_median_mOhm",
    }
    missing = sorted(required - set(d.columns))
    if missing:
        raise ValueError(f"UConn RPT table missing columns: {missing}")
    d["DCIR_median_mOhm"] = d[
        ["DCIR_chg_median_mOhm", "DCIR_dchg_median_mOhm"]
    ].median(axis=1, skipna=True)

    cell_rows = []
    for battery_id, g in d.groupby("battery_id", sort=True):
        g = g.dropna(subset=["SOH_C3", "DCIR_median_mOhm"])
        if len(g) < 2:
            continue
        first, last = g.iloc[0], g.iloc[-1]
        cell_rows.append({
            "battery_id": battery_id,
            "rpt_records": int(len(g)),
            "initial_SOH": float(first["SOH_C3"]),
            "final_SOH": float(last["SOH_C3"]),
            "SOH_change": float(last["SOH_C3"] - first["SOH_C3"]),
            "initial_DCIR_mOhm": float(first["DCIR_median_mOhm"]),
            "final_DCIR_mOhm": float(last["DCIR_median_mOhm"]),
            "DCIR_growth_pct": float(100 * (last["DCIR_median_mOhm"] / first["DCIR_median_mOhm"] - 1)),
            "spearman_SOH_DCIR": spearman(g["SOH_C3"], g["DCIR_median_mOhm"]),
        })
    cells = pd.DataFrame(cell_rows)
    pooled = d.dropna(subset=["SOH_C3", "DCIR_median_mOhm"])
    summary = {
        "rpt_records": int(len(d)),
        "battery_count": int(d["battery_id"].nunique()),
        "pooled_spearman_SOH_DCIR": spearman(pooled["SOH_C3"], pooled["DCIR_median_mOhm"]),
        "median_cell_spearman_SOH_DCIR": float(cells["spearman_SOH_DCIR"].median()),
        "median_DCIR_growth_pct": float(cells["DCIR_growth_pct"].median()),
        "median_SOH_change": float(cells["SOH_change"].median()),
        "scope_note": "External UConn LFP/graphite RPT evidence; not pooled with XJTU NCM training data.",
    }
    d.to_csv(args.output / "uconn_rpt_capacity_dcir_with_median.csv", index=False, encoding="utf-8-sig")
    cells.to_csv(args.output / "uconn_capacity_dcir_cell_summary.csv", index=False, encoding="utf-8-sig")
    (args.output / "uconn_capacity_dcir_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    fig, axes = plt.subplots(1, 2, figsize=(10.2, 4.0))
    for battery_id, g in d.groupby("battery_id", sort=True):
        axes[0].plot(g["rpt_index"], g["SOH_C3"], marker="o", ms=2.5, lw=1.1, label=battery_id.replace("UCONN:", ""))
    axes[0].set(xlabel="RPT序号", ylabel="SOH（C/3容量）", title="UConn实测容量退化")
    axes[0].legend(ncol=2, fontsize=7, frameon=False)
    scatter = axes[1].scatter(
        pooled["SOH_C3"], pooled["DCIR_median_mOhm"],
        c=pooled["rpt_index"], cmap="viridis", s=18, alpha=0.72,
    )
    axes[1].set(xlabel="SOH（C/3容量）", ylabel="DCIR中位数/mΩ", title="实测SOH与DCIR关系")
    fig.colorbar(scatter, ax=axes[1], label="RPT序号")
    fig.suptitle(
        f"UConn外部实测佐证：Spearman ρ={summary['pooled_spearman_SOH_DCIR']:.3f}",
        fontsize=11,
    )
    fig.tight_layout()
    fig.savefig(args.output / "uconn_capacity_dcir_evidence.png", dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
