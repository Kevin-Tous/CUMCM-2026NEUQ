"""Extract capacity and pulse-DCIR evidence from a UConn raw ZIP archive.

Example:
  python code/extract_uconn_rpt.py --zip "Batch 1 Part 1.zip" \
      --output code/output/uconn/uconn_rpt_capacity_dcir.csv

The script processes every cell directory found in the selected archive.  The
paper used all six directories available in Batch 1 Part 1; no outcome-based
cell selection is performed.
"""
from __future__ import annotations

import argparse
import re
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd


REQUIRED = {
    "Record number", "State", "Current(A)", "Voltage(V)", "Capacity(Ah)",
    "Date(h:min:s.ms)", "Segment", "Pulse Type", "Pulse Index",
}


def pulse_dcir(frame: pd.DataFrame, pulse_type: str) -> tuple[float, float]:
    """Return median and SOC-50 proxy DCIR from slow-pulse current steps.

    For each pulse index, DCIR is |ΔV/ΔI| at the first step between the C/5
    conditioning current and the approximately 1C pulse.  Pulse indices 1--9
    are ordered by SOC, so index 5 is the SOC-50 proxy.
    """
    values: dict[int, float] = {}
    use = frame[(frame["Segment"] == "slowpulse") & (frame["Pulse Type"] == pulse_type)]
    for index, group in use.groupby("Pulse Index"):
        current = group["Current(A)"].to_numpy(float)
        voltage = group["Voltage(V)"].to_numpy(float)
        steps = np.flatnonzero(np.abs(np.diff(current)) > 0.5)
        if not len(steps):
            continue
        # The first large step is C/5 -> ~1C; later steps are pulse removal.
        j = int(steps[0])
        di = current[j + 1] - current[j]
        if abs(di) > 1e-9:
            values[int(index)] = abs((voltage[j + 1] - voltage[j]) / di) * 1000.0
    if not values:
        return np.nan, np.nan
    return float(np.median(list(values.values()))), float(values.get(5, np.nan))


def extract_member(archive: zipfile.ZipFile, member: str) -> dict[str, object]:
    with archive.open(member) as stream:
        frame = pd.read_csv(stream)
    missing = sorted(REQUIRED - set(frame.columns))
    if missing:
        raise ValueError(f"{member}: missing columns {missing}")
    parts = Path(member).parts
    cell = parts[-2]
    match = re.search(r"RPT\s+(\d+)\.csv$", parts[-1], flags=re.I)
    if not match:
        raise ValueError(f"Cannot parse RPT index: {member}")
    rpt_index = int(match.group(1))
    ref_dchg = frame.loc[frame["Segment"] == "ref_dchg", "Capacity(Ah)"]
    one_c = frame.loc[
        (frame["State"] == "CCCV DChg") & (frame["Segment"] == "other"),
        "Capacity(Ah)",
    ]
    chg_med, chg_50 = pulse_dcir(frame, "chg")
    dchg_med, dchg_50 = pulse_dcir(frame, "dchg")
    date = pd.to_datetime(frame["Date(h:min:s.ms)"], errors="coerce").min()
    return {
        "dataset": "UConn_Batch1_Part1",
        "battery_id": f"UCONN:{cell}",
        "cell_code": cell,
        "rpt_index": rpt_index,
        "test_date": date.isoformat(sep=" ") if pd.notna(date) else "",
        "capacity_C3_Ah": float(ref_dchg.max()) if len(ref_dchg) else np.nan,
        "capacity_1C_Ah": float(one_c.max()) if len(one_c) else np.nan,
        "source_member": member,
        "source_rows": int(len(frame)),
        "DCIR_chg_median_mOhm": chg_med,
        "DCIR_chg_SOC50_mOhm": chg_50,
        "DCIR_dchg_median_mOhm": dchg_med,
        "DCIR_dchg_SOC50_mOhm": dchg_50,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--zip", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    rows = []
    with zipfile.ZipFile(args.zip) as archive:
        members = sorted(
            n for n in archive.namelist()
            if re.search(r"/RPT\s+\d+\.csv$", n, flags=re.I)
            and not n.startswith("__MACOSX/")
        )
        if not members:
            raise ValueError("No raw RPT CSV files found in archive")
        for number, member in enumerate(members, 1):
            print(f"[{number}/{len(members)}] {member}", flush=True)
            rows.append(extract_member(archive, member))
    out = pd.DataFrame(rows).sort_values(["battery_id", "rpt_index"])
    out["initial_capacity_C3_Ah"] = out.groupby("battery_id")["capacity_C3_Ah"].transform("first")
    out["SOH_C3"] = out["capacity_C3_Ah"] / out["initial_capacity_C3_Ah"]
    out["quality_flag"] = np.where(
        out[["capacity_C3_Ah", "DCIR_chg_median_mOhm", "DCIR_dchg_median_mOhm"]].notna().all(axis=1),
        "ok", "missing_metric",
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(args.output, index=False, encoding="utf-8-sig")
    print(f"Wrote {len(out)} RPT rows from {out.battery_id.nunique()} cells to {args.output}")


if __name__ == "__main__":
    main()
