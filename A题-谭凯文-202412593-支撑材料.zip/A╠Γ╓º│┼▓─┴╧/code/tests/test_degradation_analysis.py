import importlib.util
import unittest
from pathlib import Path

import numpy as np
import pandas as pd


MODULE_PATH = Path(__file__).resolve().parents[1] / "degradation_analysis.py"
SPEC = importlib.util.spec_from_file_location("degradation_analysis", MODULE_PATH)
MOD = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MOD)


class PersonAPipelineTests(unittest.TestCase):
    def test_three_segment_breaks_recovers_two_transitions(self):
        x = np.arange(1, 301)
        y = np.piecewise(
            x.astype(float),
            [x <= 60, (x > 60) & (x <= 230), x > 230],
            [lambda z: 1 - 0.00005 * z, lambda z: 0.997 - 0.00030 * (z - 60), lambda z: 0.946 - 0.0018 * (z - 230)],
        )
        b1, b2, smooth = MOD.three_segment_breaks(x, y)
        self.assertLess(abs(b1 - 60), 25)
        self.assertLess(abs(b2 - 230), 25)
        self.assertEqual(len(smooth), len(y))

    def test_simulation_outputs_are_separated_and_physical(self):
        sim, sensitivity = MOD.simulate_capacity_resistance()
        self.assertTrue(sim["value_provenance"].str.contains("simulation").all())
        self.assertTrue(sim["SOH_simulated"].between(0.19, 1.001).all())
        self.assertTrue((sim["DCIR_proxy_mOhm"] > 0).all())
        baseline = sim[sim.scenario == "baseline"].sort_values("cycle")
        self.assertTrue(baseline.SOH_simulated.is_monotonic_decreasing)
        self.assertTrue(baseline.DCIR_proxy_mOhm.is_monotonic_increasing)
        self.assertTrue(np.isclose(sensitivity.normalized_weight.sum(), 1.0))

    def test_manifest_distinguishes_derived_nasa_files(self):
        manifest = pd.read_csv(MOD.DATA_OUT / "feature_dataset_manifest.csv")
        derived = manifest[manifest.dataset == "NASA_dqdv"]
        self.assertEqual(len(derived), 34)
        self.assertFalse(derived.independent_cell.astype(bool).any())


if __name__ == "__main__":
    unittest.main()
